﻿using System;
using System.Collections.Generic;
using System.Text;
using M3_library;
using System.Linq;
using System.IO;

namespace ModelRunner_library
{
    public class StripIntercropModel : Model
    {
        // Class variable
        private int numberOfCrops;
        private int numberOfDays;
        private int numberOfSharedOutputVariables;
        private int numberOfOutputVariables;
        private int numberOfCropSpecificVariables;
        private StripIntercrop intercrop;

        public StripIntercropModel()
        {
            numberOfDays = -99;
            numberOfCrops = -99;
            numberOfSharedOutputVariables = -99;
            numberOfCropSpecificVariables = -99;
            numberOfOutputVariables = -99;
        }

        // Methods
        public override Farmer InitializeFarmer()
        {
            FarmerFileReader farmerFileReader;

            farmerFileReader = new FarmerFileReader();
            farmer = farmerFileReader.ReadFarmerFile(farmerFilePath);
            cropFilePaths = farmer.CropFilePaths;
            return farmer;
        }
        public override Model InitializeModelComponents()
        {
            farmer = InitializeFarmer();
            intercrop = InitializeStripIntercrop(farmer);
            soil = InitializeSoil(soilFilePath);
            InitializeWeatherStation(weatherFilePath, weatherStationFilePath);
            timer = InitializeTimer(farmer);
            return this;
        }
        public override Soil InitializeSoil(string soilFilePath)
        {
            SoilFileReader soilFileReader;

            soilFileReader = new SoilFileReader();
            soil = soilFileReader.ReadSoilFile(soilFilePath);
            soil.SoilMineralNitrogen.InitialzeSoilMineralNitrogen();
            return soil;
        }
        public StripIntercrop InitializeStripIntercrop(Farmer farmer)
        {
            StripIntercrop intercrop;
            StripIntercropReader intercropFileReader;

            intercropFileReader = new StripIntercropReader();
            intercropFileReader.FilePaths = cropFilePaths;
            intercrop = intercropFileReader.ReadStripIntercropFromCSV();
            intercrop = intercrop.InitializeStripIntercrop();

            for (int i = 0; i < intercrop.Crops.Length; i++)
            {
                intercrop.Crops[i].IsCropEmerged = false;
                intercrop.Crops[i].HarvestDate = farmer.HarvestDates[i];
                intercrop.Crops[i].Phenology.SowingDate = farmer.SowingDates[i];
                intercrop.Crops[i].SowingDensity = farmer.SowingDensities[i];
                intercrop.Crops[i].StripWidth = farmer.StripWidths[i];
            }
            return intercrop;
        }
        public override Timer InitializeTimer(Farmer farmer)
        {
            Timer timer;
            timer = new Timer();
            timer.StartSimulationDate = farmer.SowingDates.Min().AddDays(0);
            timer.EndSimulationDate = farmer.HarvestDates.Max().AddDays(1);
            return timer;
        }
        public override WeatherStation InitializeWeatherStation(string weatherFilePath, string weatherStationFilePath)
        {
            DailyWeather[] dailyWeatherRecords;
            WeatherFileReader weatherFileReader;
            WeatherStationReader weatherStationReader;

            weatherFileReader = new WeatherFileReader();
            weatherStationReader = new WeatherStationReader();

            dailyWeatherRecords = weatherFileReader.ReadWeatherFromCSV(weatherStationID, weatherFilePath);
            weatherStation = weatherStationReader.ReadWeatherStationFromFile(weatherStationID, weatherStationFilePath);
            weatherStation.WeatherRecords = dailyWeatherRecords;

            return weatherStation;
        }
        public override string[] SaveHeader()
        {
            string[] header;

            header = new string[numberOfOutputVariables];
            header[0] = "Date";
            header[1] = "Year";
            header[2] = "Day of year";
            header[3] = "Month";
            header[4] = "Day";
            header[5] = "Soil nitrogen amonut (kg m-2)";
            header[6] = "Net mineralization rate (kg N m-2 d-1)";
            header[7] = "Fertilization rate (kg N m-2 d-1)";
            header[8] = "Nitrogen uptake rate (kg N m-2 d-1)";
            header[9] = "Soil mineral nitrogen net growth rate (kg N m-2 d-1)";

            for (int i = 0; i < numberOfCrops; i++)
            {
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 0] = String.Format("Development stage of species {0}", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 1] = String.Format("Emergence status of species {0}", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 2] = String.Format("Aboveground dry matter weight of species {0} (kg m-2)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 3] = String.Format("Aboveground dry matter production of species {0} (kg m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 4] = String.Format("Aboveground dry mortality of species {0} (kg m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 5] = String.Format("Leaf area index of species {0} (-)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 6] = String.Format("Leaf area index of species {0} production (d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 7] = String.Format("Leaf area index of species {0} mortality (d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 8] = String.Format("Fraction of light intercepted", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 9] = String.Format("Shoot height of species {0} (m)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 10] = String.Format("Shoot height growth of species {0} (m d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 11] = String.Format("Storage organ dry matter weight {0} (kg m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 12] = String.Format("Storage organ dry matter production {0} (kg m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 13] = String.Format("Crop nitrogen amount of species {0} (kg N m-2)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 14] = String.Format("Crop nitrogen total demand {0} (kg N m-2)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 15] = String.Format("Crop nitrogen demand from soil {0} (kg N m-2)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 16] = String.Format("Crop nitrogen uptake rate of species {0} (kg N m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 17] = String.Format("Crop nitrogen fixation rate of species {0} (kg N m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 18] = String.Format("Crop nitrogen loss by senescence of species {0} (kg N m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 19] = String.Format("Crop nitrogen net growth of species {0} (kg N m-2 d-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 20] = String.Format("Crop nitrogen content of species {0} (kg N kg-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 21] = String.Format("Maximum  nitrogen content of species {0} (kg kg-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 22] = String.Format("Critical nitrogen content of species {0} (kg kg-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 23] = String.Format("Minimum  nitrogen content of species {0} (kg kg-1)", i + 1);
                header[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 24] = String.Format("Crop growth reduction factor of species {0} (-)", i + 1);
            }

            return header;
        }
        public override string[] SaveOutputRecord()
        {
            DateTime date;
            double year;
            double dayOfYear;
            double month;
            double day;
            double soilNitrogenAmount;
            double netMineralizationRate;
            double fertilizationRate;
            double nitrogenUptakeRate;
            double soilMineralNitrogenGrowth;
            string[] outputRecord;


            outputRecord = new string[numberOfOutputVariables];

            date = timer.Date;
            year = timer.Date.Year;
            dayOfYear = timer.Date.DayOfYear;
            month = timer.Date.Month;
            day = timer.Date.Day;

            soilNitrogenAmount = soil.SoilMineralNitrogen.SoilMineralNitrogenAmount;
            netMineralizationRate = soil.SoilMineralNitrogen.NetMineralizationRate;
            fertilizationRate = soil.SoilMineralNitrogen.FertilizerAmount;
            nitrogenUptakeRate = soil.SoilMineralNitrogen.SoilMineralNitrogenUptake;
            soilMineralNitrogenGrowth = soil.SoilMineralNitrogen.SoilMineralNitrogenNetGrowth;

            outputRecord[0] = Convert.ToString(date);
            outputRecord[1] = Convert.ToString(year); ;
            outputRecord[2] = Convert.ToString(dayOfYear);
            outputRecord[3] = Convert.ToString(month);
            outputRecord[4] = Convert.ToString(day);
            outputRecord[5] = Convert.ToString(soilNitrogenAmount);
            outputRecord[6] = Convert.ToString(netMineralizationRate);
            outputRecord[7] = Convert.ToString(fertilizationRate);
            outputRecord[8] = Convert.ToString(nitrogenUptakeRate);
            outputRecord[9] = Convert.ToString(soilMineralNitrogenGrowth);

            for (int i = 0; i < numberOfCrops; i++)
            {
                double developmentRate;
                bool isEmerged;
                double abovegroundDryWeight;
                double abovegroundDryWeightProduction;
                double abovegroundDryWeightMortality;
                double criticalNitrogenContent;
                double cropNitrogenAmount;
                double cropNitrogenDemand;
                double cropNitrogenDemandFromSoil;
                double cropNitrogenUptakeFromSoil;
                double cropNitrogenFixation;
                double cropNitrogenLossSenescence;
                double cropNitrogenConcentration;
                double cropNitrogenNetGrowth;
                double fractionOfLightIntercepted;
                double leafAreaIndex;
                double leafAreaIndexProduction;
                double leafAreaIndexMortality;
                double maximumNitrogenContent;
                double minimumNitrogenContent;
                double shootHeight;
                double shootHeightGrowth;
                double storageOrganProduction;
                double storageOrganWeight;
                double nitrogenCropGrowthReductionFactor;

                developmentRate = intercrop.Crops[i].Phenology.DevelopmentState;
                isEmerged = intercrop.Crops[i].IsCropEmerged;
                abovegroundDryWeight = intercrop.Crops[i].AbovegroundDryWeight;
                abovegroundDryWeightProduction = intercrop.Crops[i].AbovegroundBiomassProduction;
                abovegroundDryWeightMortality = intercrop.Crops[i].AbovegroundBiomassMortality;
                leafAreaIndex = intercrop.Crops[i].Leaf.LeafAreaIndex;
                leafAreaIndexProduction = intercrop.Crops[i].Leaf.LeafAreaIndexProduction;
                leafAreaIndexMortality = intercrop.Crops[i].Leaf.LeafAreaIndexMortality;
                fractionOfLightIntercepted = intercrop.Crops[i].FractionOfLightIntercepted;
                shootHeight = intercrop.Crops[i].Stem.ShootHeight;
                shootHeightGrowth = intercrop.Crops[i].Stem.ShootHeightGrowth;
                storageOrganProduction = intercrop.Crops[i].StorageOrgan.StorageOrganProduction;
                storageOrganWeight = intercrop.Crops[i].StorageOrgan.StorageOrganWeight;
                cropNitrogenAmount = intercrop.Crops[i].CropNitrogen.CropNitrogenAmount;
                cropNitrogenDemand = intercrop.Crops[i].CropNitrogen.CropNitrogenDemand;
                cropNitrogenDemandFromSoil = intercrop.Crops[i].CropNitrogen.CropNitrogenDemandFromSoil;
                cropNitrogenUptakeFromSoil = intercrop.Crops[i].CropNitrogen.NitrogenUptakeFromSoil;
                cropNitrogenFixation = intercrop.Crops[i].CropNitrogen.CropNitrogenFixationRate;
                cropNitrogenLossSenescence = intercrop.Crops[i].CropNitrogen.CropNitrogenLoss;
                cropNitrogenNetGrowth = intercrop.Crops[i].CropNitrogen.CropNitrogenGrowth;
                cropNitrogenConcentration = intercrop.Crops[i].CropNitrogen.CropNitrogenConcentration;
                maximumNitrogenContent = intercrop.Crops[i].CropNitrogen.MaximumNitrogenConcentration;
                criticalNitrogenContent = intercrop.Crops[i].CropNitrogen.CriticalNitrogenConcentration;
                minimumNitrogenContent = intercrop.Crops[i].CropNitrogen.MinimumNitrogenConcentration;
                nitrogenCropGrowthReductionFactor = intercrop.Crops[i].CropNitrogen.NitrogenGrowthReductionFactor;

                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 0] = Convert.ToString(developmentRate);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 1] = Convert.ToString(isEmerged);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 2] = Convert.ToString(abovegroundDryWeight);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 3] = Convert.ToString(abovegroundDryWeightProduction);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 4] = Convert.ToString(abovegroundDryWeightMortality);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 5] = Convert.ToString(leafAreaIndex);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 6] = Convert.ToString(leafAreaIndexProduction);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 7] = Convert.ToString(leafAreaIndexMortality);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 8] = Convert.ToString(fractionOfLightIntercepted);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 9] = Convert.ToString(shootHeight);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 10] = Convert.ToString(shootHeightGrowth);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 11] = Convert.ToString(storageOrganWeight);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 12] = Convert.ToString(storageOrganProduction);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 13] = Convert.ToString(cropNitrogenAmount);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 14] = Convert.ToString(cropNitrogenDemand);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 15] = Convert.ToString(cropNitrogenDemandFromSoil);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 16] = Convert.ToString(cropNitrogenUptakeFromSoil);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 17] = Convert.ToString(cropNitrogenFixation);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 18] = Convert.ToString(cropNitrogenLossSenescence);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 19] = Convert.ToString(cropNitrogenNetGrowth);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 20] = Convert.ToString(cropNitrogenConcentration);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 21] = Convert.ToString(maximumNitrogenContent);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 22] = Convert.ToString(criticalNitrogenContent);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 23] = Convert.ToString(minimumNitrogenContent);
                outputRecord[numberOfSharedOutputVariables + i * numberOfCropSpecificVariables + 24] = Convert.ToString(nitrogenCropGrowthReductionFactor);
            }

            return outputRecord;
        }
        public override void SimulateCropGrowth()
        {
            DailyWeather dailyWeather;
            DateTime[] fertilizationDates;
            double[] fertilizerAmounts;
            List<string[]> outputRecordList;
            string[] header;
            string[][] outputRecords;
            TimeSpan timeSpan;

            fertilizationDates = farmer.FertilizationDates;
            fertilizerAmounts = farmer.FertilizationAmounts;
            timer.Date = timer.StartSimulationDate;
            timeSpan = timer.EndSimulationDate.Subtract(timer.StartSimulationDate);
            numberOfDays = Convert.ToInt32(timeSpan.TotalDays);

            numberOfCrops = intercrop.Crops.Length;
            numberOfSharedOutputVariables = 10;
            numberOfCropSpecificVariables = 25;
            numberOfOutputVariables = numberOfSharedOutputVariables + numberOfCropSpecificVariables * numberOfCrops;

            outputRecordList = new List<string[]>();

            while (timer.Date < timer.EndSimulationDate)
            {
                string[] outputRecord;

                dailyWeather = weatherStation.GetDailyWeather(timer.Date);
                soil.SoilMineralNitrogen.FertilizerAmount = 0;
                for (int i = 0; i < fertilizationDates.Length; i++)
                {
                    if (timer.Date==fertilizationDates[i])
                    {                        
                        soil.SoilMineralNitrogen.FertilizerAmount = fertilizerAmounts[i];
                    }
                }               
                for (int j = 0; j < intercrop.Crops.Length; j++)
                {
                    double averageTemperature;
                    double baseTemperature;
                    double effectiveTemperature;

                    averageTemperature = dailyWeather.Temperature;
                    baseTemperature = intercrop.Crops[j].Phenology.BaseTemperature;
                    effectiveTemperature = Math.Max(0, averageTemperature - baseTemperature);

                    if (intercrop.Crops[j].IsCropEmerged == false && intercrop.Crops[j].Phenology.TemperatureSumFromSowing + effectiveTemperature >= intercrop.Crops[j].Phenology.TemperatureSumSowingToEmergence )
                    {
                        intercrop.Crops[j].IsCropEmerged = true;
                        intercrop.Crops[j].EmergeCrop(intercrop);
                    }
                    if (timer.Date == intercrop.Crops[j].HarvestDate.AddDays(1))
                    {
                        intercrop.Crops[j] = farmer.Harvest(intercrop.Crops[j]);
                    }
                }
                intercrop.CalculateGrowthIntercrop(soil, timer, weatherStation, dailyWeather);
                soil.SoilMineralNitrogen.CalculateSoilNitrogenNetGrowth();
                outputRecord = SaveOutputRecord();
                outputRecordList.Add(outputRecord);
                intercrop.GrowIntercrop();
                soil.SoilMineralNitrogen.GrowSoilNitrogen();
                timer.AddDay();
            }

            header = SaveHeader();
            outputRecords = outputRecordList.ToArray();
            WriteOutput(header, outputRecords);
        }
        public void WriteOutput(string[] header, string[][] outputRecords)
        {
            string separationSign;
            StreamWriter sw;
            string line;

            separationSign = ",";

            sw = new StreamWriter(outputFilePath);
            line = String.Join(separationSign, header);
            sw.WriteLine(line);

            for (int i = 0; i < numberOfDays; i++)
            {
                string[] outputRecord;
                outputRecord = outputRecords[i];
                line = String.Join(separationSign, outputRecord);
                sw.WriteLine(line);
            }

            sw.Close();
        }
    }
}
