﻿using System;
using System.Collections.Generic;
using System.Text;
using M3_library;

namespace ModelRunner_library
{
    public class Model
    {

        protected string[] cropFilePaths;
        protected Farmer farmer;
        protected string farmerFilePath;
        protected string outputFilePath;
        protected string[][] outputRecords;
        protected Soil soil;
        protected Timer timer;
        protected string soilFilePath;
        protected int weatherStationID;
        protected string weatherFilePath;
        protected WeatherStation weatherStation;
        protected string weatherStationFilePath;

        public Model()
        {
            cropFilePaths = new string[] { "genericCropFile.csv" };
            farmerFilePath = @"genericDirectory\\genericFarmerFile.csv";
            outputFilePath = @"genericDirectory\\genericOutputFile.csv";
            soilFilePath = @"genericDirectory\\genericSoilFile.csv";
            weatherFilePath = @"genericDirectory\\genericWeatherFile.csv";
            weatherStationID = -99;
            weatherStationFilePath = @"genericDirectory\\genericWeatherStationFile.csv";
            outputRecords = new string[1][];
            outputRecords[0] = new string[] { "generic output" };
            soil = new Soil();
            farmer = new Farmer();
            timer = new Timer();
            weatherStation = new WeatherStation();
        }

        // Methods
        public virtual Model InitializeModelComponents()
        {
            return this;
        }
        public virtual Farmer InitializeFarmer()
        {
            farmer = new Farmer();
            return farmer;
        }
        public virtual Soil InitializeSoil(string soilFilePath)
        {
            soil = new Soil();
            return soil;
        }
        public virtual Timer InitializeTimer(Farmer farmer)
        {
            timer = new Timer();
            return timer;
        }
        public virtual WeatherStation InitializeWeatherStation(string weatherFilePath, string weatherStationPath)
        {
            weatherStation = new WeatherStation();
            return weatherStation;
        }
        public virtual string[] SaveHeader()
        {
            string[] header;
            header = new string[] { "generic hearder" };
            return header;
        }
        public virtual string[] SaveOutputRecord()
        {
            string[] outputRecord;
            outputRecord = new string[] { "generic output" };
            return outputRecord;
        }
        public virtual void SimulateCropGrowth()
        {

        }
        public virtual void WriteOutput(string header, string[,] outputRecords)
        {

        }

        // Properties
        public Farmer Farmer
        {
            get
            {
                return farmer;
            }
            set
            {
                farmer = value;
            }
        }
        public string FarmerFilePath
        {
            get
            {
                return farmerFilePath;
            }
            set
            {
                farmerFilePath = value;
            }
        }
        public string OutputFilePath
        {
            get
            {
                return outputFilePath;
            }
            set
            {
                outputFilePath = value;
            }
        }

        public string SoilFilePath
        {
            get
            {
                return soilFilePath;
            }
            set
            {
                soilFilePath = value;
            }
        }

        public Timer Timer
        {
            get
            {
                return timer;
            }
            set
            {
                timer = value;
            }
        }

        public string WeatherFilePath
        {
            get
            {
                return weatherFilePath;
            }
            set
            {
                weatherFilePath = value;
            }
        }

        public WeatherStation WeatherStation
        {
            get
            {
                return weatherStation;
            }
            set
            {
                weatherStation = value;
            }
        }

        public int WeatherStationID
        {
            get
            {
                return weatherStationID;
            }
            set
            {
                weatherStationID = value;
            }
        }

        public string WeatherStationFilePath
        {
            get
            {
                return weatherStationFilePath;
            }
            set
            {
                weatherStationFilePath = value;
            }
        }
    }
}
