﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class WeatherStation
    {
        /// ---------------------------------------------------------------------------------
        /// File name:      WeatherStation.cs
        /// Author:         Herman Berghuijs
        /// Date:           November 21 2019
        /// ---------------------------------------------------------------------------------
        /// 
        /// ---------------------------------------------------------------------------------
        /// 1. Purpose
        /// ---------------------------------------------------------------------------------
        /// The file WeatherStation.cs contains the class WeatherStation. This purpose of the
        /// class WeatherStation is to store geographical information about the weather 
        /// station (city, country, longitude, lattitude), its index (which distinguishes it
        /// from other weather stations) and an array of daily weather objects that were 
        /// observed by this weather station. It also contains a function to collect the
        /// daily weather data for this weather station.
        /// 
        /// ---------------------------------------------------------------------------------
        /// 2. Description of class variables
        /// ---------------------------------------------------------------------------------
        /// 
        ///     2.1 city
        ///         Data type:      String
        ///         Variable type:  Metadata
        ///         Meaning:        Indicates the city where the weather station is located.
        ///         Unit:           Not applicable
        /// 
        ///     2.2 country
        ///         Data type:      String
        ///         Variable type:  Metadata
        ///         Meaning:        Indicates the country where the weather station is 
        ///                         located.
        ///         Unit:           Not applicable
        ///         
        ///     2.3 lattitude
        ///         Data type:      Double
        ///         Variable type:  Metadata
        ///         Meaning:        Indicates the geographical lattitude of the weather
        ///                         station
        ///         Unit:           [deg]
        ///         
        ///     2.4 longitude
        ///         Data type:      Double
        ///         Variable type:  Metadata
        ///         Meaning:        Indicates the geographical longitude of the weather
        ///                         station
        ///         Unit:           [deg]
        ///         
        ///     2.4 weatherStationID
        ///         Data type:      Integer
        ///         Variable type:  Intermediate
        ///         Meaning:        Indicates the geographical longitude of the weather 
        ///                         station
        ///         Unit:           [deg]       
        ///         
        /// ---------------------------------------------------------------------------------
        /// 3. Description of objects in this class
        /// ---------------------------------------------------------------------------------       
        ///     3.1 weatherRecords
        ///         Data Type:      DailyWeather array
        ///         Function:       Stores the daily weather data from the weather station
        /// 
        /// ---------------------------------------------------------------------------------
        /// 4. Description of methods
        /// ---------------------------------------------------------------------------------
        /// 
        ///     4.1 WeatherStation()
        ///         Type:           Constructor
        ///         Purpose:        Initializes an instance of the class WeatherStation.
        ///         Input:          None
        ///         Output type:    WeatherStation
        /// 
        ///     4.2 GetDailyWeather()
        ///         Type:           Function
        ///         Purpose:        Collects the daily weather data for a particular date.
        ///         Input:          Date
        ///         Output type:    DailyWeather
        /// 
        /// ---------------------------------------------------------------------------------

        // Class variables
        private string city;
        private string country;
        private double lattitude;
        private double longitude;
        private int weatherStationID;
        private DailyWeather[] weatherRecords;

        // Constructor
        public WeatherStation()
        {
            city = "Generic city";
            country = "Generic country";
            lattitude = -99.0;
            longitude = -99.0;
            weatherRecords = new DailyWeather[1];
            weatherRecords[0] = new DailyWeather();
            weatherStationID = -99;
        }

        // Methods
        public DailyWeather GetDailyWeather(DateTime date)
        {
            bool isDailyWeatherFound;
            int i;
            DailyWeather dailyWeather;

            dailyWeather = weatherRecords[0];
            isDailyWeatherFound = false;
            i = 0;

            while (!isDailyWeatherFound)
            {
                dailyWeather = weatherRecords[i];
                if (dailyWeather.Date == date)
                {
                    isDailyWeatherFound = true;
                }
                else
                {
                }
                if(weatherRecords[i].Date < weatherRecords[weatherRecords.Length-1].Date )
                {
                    i++;
                }
                else
                {
                    throw new Exception(String.Format("There are no weather data available for the date {0}", weatherRecords[i].Date));
                }
            }

            return dailyWeather;
        }

        // Properties
        public string City
        {
            get
            {
                return city;
            }
                
            set
            {
                city = value;
            }
        }
        public string Country
        {
            get
            {
                return country;
            }

            set
            {
                country = value;
            }
        }
        public double Lattitude
        {
            get
            {
                return lattitude;
            }

            set
            {
                lattitude = value;
            }
        }
        public double Longitude
        {
            get
            {
                return longitude;
            }

            set
            {
                longitude = value;
            }
        }
        public int WeatherStationID
        {
            get
            {
                return weatherStationID;
            }
            set
            {
                weatherStationID = value;
            }
        }
        public DailyWeather[] WeatherRecords
        {
            get
            {
                return weatherRecords;
            }
            set
            {
                weatherRecords = value;
            }
        }
    }
}
