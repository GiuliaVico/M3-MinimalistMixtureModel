﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3_library
{
    public class WeatherStationReader
    {
        WeatherStation weatherStation;

        public WeatherStationReader()
        {
            weatherStation = new WeatherStation();
        }

        public WeatherStation ReadWeatherStationFromFile(int weatherStationID, string filePath)
        {
            StreamReader sr;
            string line;
            string[] record;

            sr = new StreamReader(filePath);

            line = sr.ReadLine();
            line = sr.ReadLine();

            while(line!=null)
            {
                int weatherStationIDRecord;
                string city;
                string country;
                double lattitude;
                double longitude;

                record = line.Split(',');
                weatherStationIDRecord = Convert.ToInt32(record[0]);

                if(weatherStationIDRecord == weatherStationID)
                {
                    country = record[1];
                    city = record[2];
                    lattitude = Convert.ToDouble(record[3]);
                    longitude = Convert.ToDouble(record[4]);

                    weatherStation.WeatherStationID = weatherStationID;
                    weatherStation.Country = country;
                    weatherStation.City = city;
                    weatherStation.Lattitude = lattitude;
                    weatherStation.Longitude = longitude;

                    line = null;
                }
                else
                {
                    line = sr.ReadLine();
                }
            }
            return weatherStation;
        }


    }
}
