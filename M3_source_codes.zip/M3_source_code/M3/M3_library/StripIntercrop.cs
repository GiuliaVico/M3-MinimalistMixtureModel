﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using M3_library;

namespace M3_library
{
    public class StripIntercrop
    {
        // Class variables
        private bool crop1IsShorterCrop;
        private bool crop1IsTallerCrop;
        private Crop[] crops;
        private double weightFunction;

        // Constructor
        public StripIntercrop()
        {
            crops = new Crop[2];
            crops[0] = new Crop();
            crops[1] = new Crop();
            crop1IsShorterCrop = false;
            crop1IsTallerCrop = false;
        }

        // Methods
        public double CalculateCumulativeCompressedLeafAreaIndexUpperCanopyTallerCrop(double H, double H_diff, double L_comp)
        {
            double L_c_u;

            if (H > 0)
            {
                L_c_u = (H_diff / H) * L_comp;
            }
            else
            {
                L_c_u = 0;
            }
            return L_c_u;
        }
        public StripIntercrop CalculateGrowthIntercrop(Soil s, Timer t, WeatherStation w, DailyWeather dw)
        {
            CalculateFractionOfRadiationInterceptionPerCrop();

            for (int i = 0; i < crops.Length; i++)
            {
                crops[i] = crops[i].CalculateCropGrowth(this, s, t, w, dw);
            }
            return this;
        }
        public StripIntercrop CalculateCompressedLeafAreaIndices()
        {
            for (int i = 0; i < crops.Length; i++)
            {
                double L;
                double L_c;
                double W;
                double P;

                L = crops[i].Leaf.LeafAreaIndex;

                if (i == 0)
                {
                    P = crops[1].StripWidth;
                    W = crops[0].StripWidth;
                }
                else if (i == 1)
                {
                    P = crops[0].StripWidth;
                    W = crops[1].StripWidth;
                }
                else
                {
                    throw new Exception("The class StripIntercrop currently only supports an intercrop that consists of two species");
                }

                L_c = L * (W + P) / W;

                crops[i].Leaf.CompressedLeafAreaIndex = L_c;
            }
            return this;
        }
        public StripIntercrop CalculateFractionOfRadiationInterceptionPerCrop()
        {
            double fint_s;
            double fint_t;
            double fint_u_t;
            double fint_l_t;
            double fint_u_t_c;
            double fint_u_t_h;
            double H_t;
            double H_s;
            double H_diff;
            double IP_b;
            double IR_b;
            double k_t;
            double k_s;
            double L_t_c;
            double L_t_h;
            double L_s_c;
            double L_s_h;
            double L_u_t_c;
            double L_u_t_h;
            double L_l_t_c;
            double P;
            double SP_ni;
            double SR_ni;
            double weight;
            double W;
            int i_taller;
            int i_shorter;

            /// Check which of the two crop species is the taller crop
            FindTallerCrop();
            /// Collect the indices, heights, extinction coefficients, leaf area indices, and the
            /// strip widths of both crop species.
            i_taller = FindIndexOfTallerCrop();
            i_shorter = FindIndexOfShorterCrop();
            H_t = crops[i_taller].Stem.ShootHeight;
            H_s = crops[i_shorter].Stem.ShootHeight;
            k_t = crops[i_taller].Leaf.ExtinctionCoefficient;
            k_s = crops[i_shorter].Leaf.ExtinctionCoefficient;
            L_t_h = crops[i_taller].Leaf.LeafAreaIndex;
            L_s_h = crops[i_shorter].Leaf.LeafAreaIndex;
            P = crops[i_shorter].StripWidth;
            W = crops[i_taller].StripWidth;
            /// Calculate the compressed leaf area indices, collect them and store them into
            /// double variables.
            CalculateCompressedLeafAreaIndices();
            L_t_c = crops[i_taller].Leaf.CompressedLeafAreaIndex;
            L_s_c = crops[i_shorter].Leaf.CompressedLeafAreaIndex;
            /// Calculate the cumulative leaf area index in the upper part of the canopy of the
            /// taller crop and store it in a double variable.
            L_u_t_h = crops[i_taller].Leaf.CalculateCumulativeLeafAreaIndex(crops[i_taller], H_s);
            /// Calculate the height difference between the two crop species.
            H_diff = CalculateHeightDifference();
            /// Calculate the cumulative leaf area indices of the upper canopy of the taller crop and
            /// the lower canopy of the taller crop/
            L_u_t_c = CalculateCumulativeCompressedLeafAreaIndexUpperCanopyTallerCrop(H_t, H_diff, L_t_c);
            L_l_t_c = L_t_c - L_u_t_c;
           // L_l_t_h = L_t_h - L_u_t_h;
            /// Calculate the view factors of the sky.
            IP_b = CalculateViewFactorSpaceBetweenRowsUpperCanopy(P, H_diff);
            IR_b = CalculateViewFactorUpperCanopyTallerCrop(W, H_diff);
            /// Calculate the fraction of light that reaches the top of the canopy of the shorter crop
            /// and the fraction that reaches the top of the lower canopy of the taller crop.
            SP_ni = CalculateFractionOfRadiationAtTopCanopyShorterCrop(k_t, L_u_t_h, IP_b);
            SR_ni = CalculateFractionOfRadiationAtTopLowerCanopyTallerCrop(k_t, L_u_t_h, L_u_t_c, IR_b);
            /// Calculate the weight function.
            weight = CalculateWeightFunction(k_t, L_u_t_c, SP_ni, SR_ni);
            /// Calculates the fraction of light that is absorbed by eahc part of the caopy of the
            /// intercrop.
            fint_u_t_c = CalculateInterceptionFractionByCompressedCanopy(k_t, L_u_t_c, P, SR_ni, W);
            fint_u_t_h = CalculateInterceptionFractionHomogeneousCanopy(k_t, L_u_t_h);
            fint_u_t = CalculateInterceptionFractionUpperCanopyTallerCrop(fint_u_t_h, fint_u_t_c, weight);
            fint_l_t = CalculateInterceptionFractionLowerCanopyTallerCrop(k_t, L_l_t_c, P, SR_ni, W);
            fint_s = CalculateInterceptionFractionShorterCrop(k_s,L_s_c,P,SP_ni,W);
            fint_t = fint_u_t + fint_l_t;

            crops[i_taller].FractionOfLightIntercepted = fint_t;
            crops[i_shorter].FractionOfLightIntercepted = fint_s; 
            return this;
        }
        public double CalculateHeightDifference()
        {
            double H1;
            double H2;
            double H_diff;

            H1 = crops[0].Stem.ShootHeight;
            H2 = crops[1].Stem.ShootHeight;
            H_diff = Math.Abs(H1 - H2);

            return H_diff;
        }
        public double CalculateInterceptionFractionLowerCanopyTallerCrop(double k_t, double L_l_t_c, double P, double SR_ni, double W)
        {
            double fint_l_t;
            fint_l_t = SR_ni * (1 - Math.Exp(-k_t * L_l_t_c)) * W / (W + P);
            return fint_l_t;
        }
        public double CalculateInterceptionFractionUpperCanopyTallerCrop(double fint_u_t_h, double fint_u_t_c, double weight)
        {
            double f_int_u_t;
            f_int_u_t = (1 - weight) * fint_u_t_h + weight * fint_u_t_c;
            return f_int_u_t;
        }
        public double CalculateInterceptionFractionHomogeneousCanopy(double k, double L)
        {
            double f_int_h;
            f_int_h = 1 - Math.Exp(-k * L);
            return f_int_h;
        }
        public double CalculateInterceptionFractionByCompressedCanopy(double k, double L_c, double P, double SR_ni, double W)
        {
            double f_int_c;
            f_int_c = (W / (W + P)) * (1 - Math.Exp(-k * L_c));
            return f_int_c;
        }
        public double CalculateInterceptionFractionShorterCrop(double k_s, double L_s_c, double P, double SP_ni, double W)
        {
            double f_int_s;
            f_int_s = SP_ni * (1 - Math.Exp(-k_s * L_s_c)) * (P / (W + P));
            return f_int_s;
        }
        public double CalculateFractionOfRadiationAtTopLowerCanopyTallerCrop(double k, double L, double L_c, double IR_b)
        {
            double SR_ni;
            SR_ni = (IR_b * Math.Exp(-k * L_c)) + (1 - IR_b) * Math.Exp(-k * L);
            return SR_ni;
        }
        public double CalculateFractionOfRadiationAtTopCanopyShorterCrop(double k, double L, double IP_b)
        {
            double SP_ni;
            SP_ni = IP_b + (1 - IP_b) * Math.Exp(-k * L);
            return SP_ni;
        }
        public double CalculateWeightFunction(double k, double L_c, double SP_ni, double SR_ni)
        {
            double w;

            if (L_c > 0)
            {
                w = (SP_ni - SR_ni) / (1 - Math.Exp(-k * L_c));
            }
            else
            {
                w = 0;
            }
            return w;
        }
        public double CalculateViewFactorUpperCanopyTallerCrop(double W, double H_diff)
        {
            double IR_b;
            IR_b = (Math.Pow(Math.Pow(H_diff, 2) + Math.Pow(W, 2), 0.5) - H_diff) / W;
            return IR_b;
        }
        public double CalculateViewFactorSpaceBetweenRowsUpperCanopy(double P, double H_diff)
        {
            double IR_b;
            IR_b = (Math.Pow(Math.Pow(H_diff, 2) + Math.Pow(P, 2), 0.5) - H_diff) / P;
            return IR_b;
        }
        public int FindIndexOfShorterCrop()
        {
            int indexOfShorterCrop;
            if (crop1IsTallerCrop & !crop1IsShorterCrop)
            {
                indexOfShorterCrop = 1;
            }
            else if (!crop1IsTallerCrop & crop1IsShorterCrop)
            {
                indexOfShorterCrop = 0;
            }
            else if (!crop1IsTallerCrop & !crop1IsShorterCrop)
            {
                indexOfShorterCrop = 1;
            }
            else
            {
                throw new Exception("Crop 1 and crop 2 cannot be both the shorter crop.");
            }
            return indexOfShorterCrop;
        }
        public int FindIndexOfTallerCrop()
        {
            int indexOfTallerCrop;

            if (crop1IsTallerCrop & !crop1IsShorterCrop)
            {
                indexOfTallerCrop = 0;
            }
            else if (!crop1IsTallerCrop & crop1IsShorterCrop)
            {
                indexOfTallerCrop = 1;
            }
            else if (!crop1IsTallerCrop & !crop1IsShorterCrop)
            {
                indexOfTallerCrop = 0;
            }
            else
            {
                throw new Exception("Crop 1 and crop 2 cannot be both the taller crop.");
            }

            return indexOfTallerCrop;
        }
        public StripIntercrop FindTallerCrop()
        {
            if (crops[0].Stem.ShootHeight > crops[1].Stem.ShootHeight)
            {
                crop1IsTallerCrop = true;
                crop1IsShorterCrop = false;
            }
            else if (crops[0].Stem.ShootHeight < crops[1].Stem.ShootHeight)
            {
                crop1IsTallerCrop = false;
                crop1IsShorterCrop = true;
            }
            else
            {
                crop1IsTallerCrop = false;
                crop1IsShorterCrop = false;
            }

            return this;
        }
        public StripIntercrop GrowIntercrop()
        {
            for (int i = 0; i < crops.Length; i++)
            {
                crops[i].GrowCrop();
            }

            return this;
        }
        public StripIntercrop InitializeStripIntercrop()
        {
            for (int i = 0; i < crops.Length; i++)
            {
                crops[i].InitializeCrop();
                crops[i].CropID = i;
            }
            return this;
        }


        // Properties
        public bool Crop1IsTallerCrop
        {
            get
            {
                return crop1IsTallerCrop;
            }

            set
            {
                crop1IsTallerCrop = value;
            }
        }
        public bool Crop1IsShorterCrop
        {
            get
            {
                return crop1IsShorterCrop;
            }

            set
            {
                crop1IsShorterCrop = value;
            }
        }
        public Crop[] Crops
        {
            get
            {
                if (crops.Length == 2)
                {

                }
                else
                {
                    throw new Exception("The class StripIntercrop only supports systems with two crops");
                }
                return crops;
            }
            set
            {
                if (crops.Length == 2)
                {

                }
                else
                {
                    throw new Exception("The class StripIntercrop only supports systems with two crops");
                }
                crops = value;
            }
        }
        public double WeightFunction
        {
            get
            {
                return weightFunction;
            }
            set
            {
                weightFunction = value;
            }
        }
    }

}
