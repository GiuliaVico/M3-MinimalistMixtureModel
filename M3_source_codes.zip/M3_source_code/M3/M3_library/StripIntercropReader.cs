﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class StripIntercropReader
    {

        private CropFileReader cropFileReader;
        private string[] filePaths;

        public StripIntercropReader()
        {
            cropFileReader = new CropFileReader();
        }


        public StripIntercrop ReadStripIntercropFromCSV()
        {

            StripIntercrop intercrop;
            Crop[] crops;

            intercrop = new StripIntercrop();
            crops = new Crop[filePaths.Length];

            for (int i = 0; i < filePaths.Length; i++)
            {
                Crop crop;
                string filePath;

                filePath = filePaths[i];
                crop = cropFileReader.ReadCropFromCSV(filePath);
                crops[i] = crop;
            }

            intercrop.Crops = crops;
            return intercrop;
        }

        public CropFileReader CropFileReader
        {
            get
            {
                return cropFileReader;
            }
            set
            {
                cropFileReader = value;
            }
        }

        public string[] FilePaths
        {
            get
            {
                return filePaths;
            }
            set
            {
                filePaths = value;
            }
        }

    }
}
