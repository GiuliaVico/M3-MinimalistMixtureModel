﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace M3_library
{
    public class WeatherFileReader
    {
        WeatherStation weatherStation;

        // Constructor
        public WeatherFileReader()
        {
            weatherStation = new WeatherStation();
        }

        // Methods
        public DailyWeather[] ReadWeatherFromCSV(int weatherStationID, string weatherFilePath)
        {
            DailyWeather[] dailyWeatherArray;
            List<DailyWeather> dailyWeatherList;
            StreamReader sr;
            string line;
            string[] record;

            dailyWeatherList = new List<DailyWeather>();
            weatherStation.WeatherStationID = weatherStationID;

            sr = new StreamReader(weatherFilePath);
            line = sr.ReadLine();
            line = sr.ReadLine();
            
            while(line!=null)
            {
                CultureInfo provider;
                DailyWeather dailyWeather;
                DateTime date;
                double minimumTemperature;
                double maximumTemperature;
                double radiation;
                int weatherStationIDRecord;
                string dateFormat;

                provider = CultureInfo.InvariantCulture;
                dateFormat = "yyyy-MM-dd";

                record = line.Split(',');
                dailyWeather = new DailyWeather();
                weatherStationIDRecord = Convert.ToInt32(record[0]);
                date = DateTime.ParseExact(record[1], dateFormat, provider);
                minimumTemperature = Convert.ToDouble(record[6]);
                maximumTemperature = Convert.ToDouble(record[7]);
                radiation = Convert.ToDouble(record[9]);             
                dailyWeather.Date = date;
                dailyWeather.MinimumTemperature = minimumTemperature;
                dailyWeather.MaximumTemperature = maximumTemperature;
                dailyWeather.Radiation = radiation * 1e6;
                ///
                if (weatherStationIDRecord == weatherStationID)
                {
                    dailyWeatherList.Add(dailyWeather);
                }
                else
                {
                }
                line = sr.ReadLine();
            }

            dailyWeatherArray = dailyWeatherList.ToArray();
            return dailyWeatherArray;
        }
    }
}
