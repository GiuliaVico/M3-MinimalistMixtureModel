﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class StorageOrgan
    {
        private double storageOrganWeight;
        private double storageOrganProduction;

        public StorageOrgan()
        {
            storageOrganWeight = -99;
            storageOrganProduction = -99;
        }

        public StorageOrgan CalculateStorageOrganProduction(Crop c, DailyWeather dw)
        {
            double dev;
            double f_int;
            double g_N;
            double par_int;
            double f_so;
            double f_par;
            double rad;
            double rue;
            double g_so;
            PhysicalConstants py;

            py = new PhysicalConstants();
            dev = c.Phenology.DevelopmentState;
            f_par = py.FractionOfPARInRadiation;
            g_N = c.CropNitrogen.NitrogenGrowthReductionFactor;
            rue = c.Leaf.RadiationUseEfficiency;
            f_int = c.FractionOfLightIntercepted;
            rad = dw.Radiation;

            if (dev < 2)
            {                
                c = c.CalculatePartitioningFactorToStorageOrgans();
                f_so = c.PartitioningFractionToStorageOrgans;
                par_int = rad * f_int * f_par;
                g_so = g_N * rue * par_int * f_so;
                storageOrganProduction = g_so;
            }
            else
            {
                storageOrganProduction = 0;
            }

            return this;
        }

        public double StorageOrganWeight
        {
            get
            {
                return storageOrganWeight;
            }
            set
            {
                storageOrganWeight = value;
            }
        }

        public double StorageOrganProduction
        {
            get
            {
                return storageOrganProduction;
            }
            set
            {
                storageOrganProduction = value;
            }
        }
    }
}
