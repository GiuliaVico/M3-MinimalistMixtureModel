﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class CropNitrogen
    {       
        private double fractionCriticalToMaximumNitrogenConcentration;
        private double fractionMinimumToMaximumNitrogenConcentration;
        private double fractionOfNitrogenDemandFixed;
        private double coefficientACriticalNitrogenConcentration;
        private double coefficientAMaximumNitrogenConcentration;
        private double coefficientAMinimumNitrogenConcentration;
        private double coefficientBCriticalNitrogenConcentration;
        private double coefficientBMaximumNitrogenConcentration;
        private double coefficientBMinimumNitrogenConcentration;
        private double cropNitrogenAmount;
        private double cropNitrogenDemand;
        private double cropNitrogenDemandFromSoil;
        private double cropNitrogenFixationRate;
        private double cropNitrogenGrowth;
        private double cropNitrogenConcentration;
        private double cropNitrogenLoss;
        private double criticalNitrogenConcentration;
        private double minimumNitrogenConcentration;
        private double maximumNitrogenConcentration;
        private double maximumNitrogenConcentrationEarlyGrowth;
        private double nitrogenGrowthReductionFactor;
        private double nitrogenUptakeFromSoil;
        private double timeCoefficient;

        public CropNitrogen()
        {
            fractionCriticalToMaximumNitrogenConcentration = -99;
            fractionMinimumToMaximumNitrogenConcentration = -99;
            cropNitrogenAmount = -99;
            cropNitrogenDemand = -99;
            criticalNitrogenConcentration = -99;
            minimumNitrogenConcentration = -99;
            maximumNitrogenConcentration = -99;
            maximumNitrogenConcentration = -99;
            timeCoefficient = -99;
        }

        public double CalculateCritcialNitrogenConcentration(StripIntercrop ic, Crop c)
        {
            double B;
            double coeffACrit;
            double coeffB;
            double fCrit;
            double Nconc_max;
            double Nconc_crit;
            double w_strip;
            double sum_w_strips;

            coeffACrit = coefficientACriticalNitrogenConcentration;
            coeffB = coefficientBCriticalNitrogenConcentration;
            B = c.AbovegroundDryWeight;
            fCrit = fractionCriticalToMaximumNitrogenConcentration;
            Nconc_max = maximumNitrogenConcentrationEarlyGrowth;
            w_strip = c.StripWidth;
            sum_w_strips = 0;

            for (int i = 0; i < ic.Crops.Length; i++)
            {
                sum_w_strips = sum_w_strips + ic.Crops[i].StripWidth;
            }
            Nconc_crit = fCrit * Nconc_max * Math.Min(1, Math.Pow(B / (coeffACrit * w_strip / sum_w_strips), -coeffB));

            criticalNitrogenConcentration = Nconc_crit;

            return Nconc_crit;
        }
        public double CalculateCropNitrogenConcentration(Crop c)
        {
            double B;
            double Na;
            double Nconc;
            Na = cropNitrogenAmount;
            B = c.AbovegroundDryWeight;
            if (c.AbovegroundDryWeight > 0)
            {
                Nconc = Na / B;
            }
            else
            {
                Nconc = 0;
            }
            cropNitrogenConcentration = Nconc;
            return cropNitrogenConcentration;
        }
        public double CalculateCropNitrogenDemand(StripIntercrop ic, Crop c)
        {
            double B;
            double D;
            double N_a;
            double N_conc;
            double Nconc_max;
            double N_a_max;
            
            if (c.IsCropEmerged & !c.IsCropHarvested)
            {
                B = c.AbovegroundDryWeight;
                N_a = cropNitrogenAmount;
                N_conc = CalculateCropNitrogenConcentration(c);
                Nconc_max = CalculateMaximumNitrogenConcentration(ic, c);
                N_a_max = Nconc_max * B;

                if (Nconc_max > N_conc)
                {
                    D = N_a_max - N_a;
                }
                else
                {
                    D = 0;
                }
            }
            else
            {
                D = 0;
            }

            cropNitrogenDemand = D;
            return D;
        }
        public double CalculateCropNitrogenDemandFromSoil()
        {
            double D;
            double D_soil;
            double f_Nfix;

            D = cropNitrogenDemand;
            f_Nfix = fractionOfNitrogenDemandFixed;

            D_soil = (1 - f_Nfix) * D;
            cropNitrogenDemandFromSoil = D_soil;
            return D_soil;
        }
        public double CalculateCropNitrogenFixed()
        {
            double D;
            double N_fixed;
            double f_Nfix;

            D = cropNitrogenDemand;
            f_Nfix = fractionOfNitrogenDemandFixed;
            N_fixed = f_Nfix * D;
            cropNitrogenFixationRate = N_fixed;

            return N_fixed;
        }
        public double CalculateCropNitrogenGrowth(Crop c)
        {

            double N_fix;
            double u;
            double N_loss;
            double dN;

            N_fix = cropNitrogenFixationRate;
            N_loss = CalculateCropNitrogenLoss(c);
            u = nitrogenUptakeFromSoil;
            dN = u + N_fix - N_loss;

            cropNitrogenConcentration = CalculateCropNitrogenConcentration(c);
            cropNitrogenGrowth = dN;
            return dN;
        }
        public double CalculateCropNitrogenLoss(Crop c)
        {
            double mu_crop;
            double Na_min;
            double Nconc_min;
            double Na_loss;

            mu_crop = c.AbovegroundBiomassMortality;
            Nconc_min = minimumNitrogenConcentration;
            Na_min = Nconc_min * mu_crop;
            Na_loss = mu_crop * Na_min;
            cropNitrogenLoss = Na_loss;

            return Na_loss;
        }
        public double CalculateGrowthReductionFactor(Crop c)
        {
            double B;
            double gr_N;
            double Nconc_min;
            double Nconc_crit;
            double Na;
            double Na_min;
            double Na_crit;

            if (c.IsCropEmerged)
            {
                B = c.AbovegroundDryWeight;
                Na = cropNitrogenAmount;
                Nconc_crit = criticalNitrogenConcentration;
                Nconc_min = minimumNitrogenConcentration;
                Na_min = Nconc_min * B;
                Na_crit = Nconc_crit * B;

                gr_N = Math.Max(0, Math.Min(1, (Na - Na_min) / (Na_crit - Na_min)));
            }
            else
            {
                gr_N = 1;
            }

            nitrogenGrowthReductionFactor = gr_N;
            return gr_N;
        }
        public double CalculateMaximumNitrogenConcentration(StripIntercrop ic, Crop c)
        {
            double coeffAMax;
            double coeffB;
            double B;
            double Nconc_max;
            double Nconc_max_0;
            double w_strip;
            double sum_w_strips;


            coeffAMax = coefficientAMaximumNitrogenConcentration;
            coeffB = coefficientBMaximumNitrogenConcentration;
            B = c.AbovegroundDryWeight;
            Nconc_max_0 = maximumNitrogenConcentrationEarlyGrowth;
            w_strip = c.StripWidth;
            sum_w_strips = 0;
            for (int i = 0; i < ic.Crops.Length; i++)
            {
                sum_w_strips = sum_w_strips + ic.Crops[i].StripWidth;
            }
            if (B == 0)
            {
                Nconc_max = Nconc_max_0;
            }
            else
            {
                Nconc_max = Nconc_max_0 * Math.Min(1, Math.Pow(B / (coeffAMax * w_strip / sum_w_strips), -coeffB));
            }
            maximumNitrogenConcentration = Nconc_max;
            return Nconc_max;
        }
        public double CalculateMinimumNitrogenConcentration(StripIntercrop ic, Crop c)
        {
            /// -------------------------------------------------------------------------
            /// CropNitrogen.CalculateMinimumNitrogenConcentration()
            /// -------------------------------------------------------------------------
            /// 
            /// -------------------------------------------------------------------------
            /// 0. Description
            /// -------------------------------------------------------------------------
            /// The purpose of CalculateMinimumNitrogenConcentration() is to calculate
            /// for a given biomass what the minimal nitrogen concentration of the crop
            /// is. For low biomasses, the minimal nitrogen is a fraction of the maximum
            /// nitrogen concentration of the crop. Once a certain biomass has been reached,
            /// the minimal nitrogen concentration starts to decline as a function of the
            /// biomass. Therefore, such a curve is called a dilution curve. It is calculated
            /// as follows. First an intermediate variable a_min is calculated from a
            /// previously calculated maximum concentration of crop nitrogen:
            /// 
            /// a_min(t) = Nconc_max(t) * f_min / 1.5^-b                              (1)
            /// 
            /// a_min(t):       Intermediate variable that is used to calculate the minimal
            ///                 nitrogen concentration at time t [kg N] * [m^-2]
            /// Nconc_max(t):   Maximum crop nitrogen concentration at time t [kg N] *
            ///                 [kg^-1 biomass]
            /// b:              Shape parameter
            /// f_min:          Fraction of minimal nitrogen concentration to maximum
            ///                 nitrogen concentration.
            /// 
            /// Subsequently, a_crit(t) is used to calculate the minimal nitrogen 
            /// concentration:
            /// 
            /// N_conc_crit(t) = min(f_crit*N_conc_max(t), a_crit(t)*(10*B(t))^-b)    (2)
            /// 
            /// B(t):           Total aboveground biomass at time t.
            /// N_conc_crit(t): Minimal crop nitrogen concentration at time t [kg N] *
            ///                 [kg^-1 biomass]            
            /// Nconc_max(t):   Maximum crop nitrogen concentration at time t [kg N] *
            ///                 [kg^-1 biomass]            
            /// -------------------------------------------------------------------------
            ///  
            /// -------------------------------------------------------------------------
            /// 1. Declare variables
            /// -------------------------------------------------------------------------
            double coeffAMin;
            double b;
            double B;
            double fMin;
            double Nconc_max;
            double Nconc_min;
            double sum_w_strips;
            double w_strip;
            /// -------------------------------------------------------------------------
            /// 2. Initialize variables
            /// -------------------------------------------------------------------------
            coeffAMin = coefficientAMinimumNitrogenConcentration;
            b = coefficientBMinimumNitrogenConcentration;
            B = c.AbovegroundDryWeight;
            fMin = fractionMinimumToMaximumNitrogenConcentration;
            //Nconc_max = maximumNitrogenConcentration;
            Nconc_max = maximumNitrogenConcentrationEarlyGrowth;
            w_strip = c.StripWidth;
            sum_w_strips = 0;
            /// -------------------------------------------------------------------------
            /// 3. Calculations
            /// -------------------------------------------------------------------------
            for (int i = 0; i < ic.Crops.Length; i++)
            {
                sum_w_strips = sum_w_strips + ic.Crops[i].StripWidth;
            }

            Nconc_min = fMin * Nconc_max * Math.Min(1, Math.Pow(B / (coeffAMin * w_strip / sum_w_strips), -b));

            /// -------------------------------------------------------------------------
            /// 4. Return output
            /// -------------------------------------------------------------------------
            minimumNitrogenConcentration = Nconc_min;
            return Nconc_min;
            /// -------------------------------------------------------------------------
        }
        public CropNitrogen GrowCropNitrogen(Crop c)
        {
            cropNitrogenAmount = cropNitrogenAmount + cropNitrogenGrowth;
            return this;
        }
        public CropNitrogen InitializeCropNitrogen()
        {
            /// -------------------------------------------------------------------------
            /// CropNitrogen.InitializeCropNitrogen
            /// -------------------------------------------------------------------------
            /// Sets the nitrogen demand of the crop and the critical, minimal and maximal
            /// crop nitrogen concentration equal to 0.
            /// -------------------------------------------------------------------------
            ///
            /// -------------------------------------------------------------------------
            /// 1. Initialize variables
            ///  -------------------------------------------------------------------------
            cropNitrogenDemand = 0;
            cropNitrogenAmount = 0;
            cropNitrogenConcentration = 0;
            criticalNitrogenConcentration = 0;
            minimumNitrogenConcentration = 0;
            maximumNitrogenConcentration = 0;
            return this;
        }

        public double FractionOfNitrogenDemandFixed
        {
            get
            {
                return fractionOfNitrogenDemandFixed;
            }
            set
            {
                fractionOfNitrogenDemandFixed = value;
            }
        }
        public double FractionCriticalToMaximumNitrogenConcentration
        {
            get
            {
                return fractionCriticalToMaximumNitrogenConcentration;
            }
            set
            {
                fractionCriticalToMaximumNitrogenConcentration = value;
            }
        }

        public double FractionMinimumToMaximumNitrogenConcentration
        {
            get
            {
                return fractionMinimumToMaximumNitrogenConcentration;
            }
            set
            {
                fractionMinimumToMaximumNitrogenConcentration = value;
            }
        }
        public double CoefficientACriticalNitrogenConcentration
        {
            get
            {
                return coefficientACriticalNitrogenConcentration;
            }
            set
            {
                coefficientACriticalNitrogenConcentration = value;
            }
        }
        public double CoefficientAMaximumNitrogenConcentration
        {
            get
            {
                return coefficientAMaximumNitrogenConcentration;
            }
            set
            {
                coefficientAMaximumNitrogenConcentration = value;
            }
        }
        public double CoefficientAMinimumNitrogenConcentration
        {
            get
            {
                return coefficientAMinimumNitrogenConcentration;
            }
            set
            {
                coefficientAMinimumNitrogenConcentration = value;
            }
        }
        public double CoefficientBCriticalNitrogenConcentration
        {
            get
            {
                return coefficientBCriticalNitrogenConcentration;
            }
            set
            {
                coefficientBCriticalNitrogenConcentration = value;
            }
        }
        public double CoefficientBMaximumNitrogenConcentration
        {
            get
            {
                return coefficientBMaximumNitrogenConcentration;
            }
            set
            {
                coefficientBMaximumNitrogenConcentration = value;
            }
        }
        public double CoefficientBMinimumNitrogenConcentration
        {
            get
            {
                return coefficientBMinimumNitrogenConcentration;
            }
            set
            {
                coefficientBMinimumNitrogenConcentration = value;
            }
        }
        public double CropNitrogenAmount
        {
            get
            {
                return cropNitrogenAmount;
            }
            set
            {
                cropNitrogenAmount = value;
            }
        }
        public double CropNitrogenFixationRate
        {
            get
            {
                return cropNitrogenFixationRate;
            }
            set
            {
                cropNitrogenFixationRate = value;
            }
        }
        public double CropNitrogenDemandFromSoil
        {
            get
            {
                return cropNitrogenDemandFromSoil;
            }
            set
            {
                cropNitrogenDemandFromSoil = value;
            }
        }

        public double CropNitrogenGrowth
        {
            get
            {
                return cropNitrogenGrowth;
            }
            set
            {
                cropNitrogenGrowth = value;
            }
        }
        public double CropNitrogenLoss
        {
            get
            {
                return cropNitrogenLoss;
            }
            set
            {
                cropNitrogenLoss = value;
            }
        }

        public double CropNitrogenDemand
        {
            get
            {
                return cropNitrogenDemand;
            }
            set
            {
                cropNitrogenDemand = value;
            }
        }

        public double CropNitrogenConcentration
        {
            get
            {
                return cropNitrogenConcentration;
            }
            set
            {
                cropNitrogenConcentration = value;
            }
        }

        public double MaximumNitrogenConcentration
        {
            get
            {
                return maximumNitrogenConcentration;
            }
            set
            {
                maximumNitrogenConcentration = value;
            }
        }

        public double MaximumNitrogenConcentrationEarlyGrowth
        {
            get
            {
                return maximumNitrogenConcentrationEarlyGrowth;
            }
            set
            {
                maximumNitrogenConcentrationEarlyGrowth = value;
            }
        }

        public double CriticalNitrogenConcentration
        {
            get
            {
                return criticalNitrogenConcentration;
            }
            set
            {
                criticalNitrogenConcentration = value;
            }
        }

        public double MinimumNitrogenConcentration
        {
            get
            {
                return minimumNitrogenConcentration;
            }
            set
            {
                minimumNitrogenConcentration = value;
            }
        }

        public double NitrogenUptakeFromSoil
        {
            get
            {
                return nitrogenUptakeFromSoil;
            }
            set
            {
                nitrogenUptakeFromSoil = value;
            }
        }

        public double NitrogenGrowthReductionFactor
        {
            get
            {
                return nitrogenGrowthReductionFactor;
            }
            set
            {
                nitrogenGrowthReductionFactor = value;
            }
        }

        public double TimeCoefficient
        {
            get
            {
                return timeCoefficient;
            }
            set
            {
                timeCoefficient = value;
            }
        }
    }
}