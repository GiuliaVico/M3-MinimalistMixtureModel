﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace M3_library
{
    public class SoilMineralNitrogen
    {
        private double initialNitrogenAmount;
        private double fertilizerAmount;
        private double fractionOfFertilizerRecovered;
        private double netMineralizationRate;
        private double soilNitrogenNetGrowth;
        private double soilMineralNitrogenAmount;
        private double soilMineralNitrogenProduction;
        private double soilMineralNitrogenUptake;

        // Constructor
        public SoilMineralNitrogen()
        {
            initialNitrogenAmount = -99;
            fertilizerAmount = -99;
            soilMineralNitrogenAmount = -99;
            soilMineralNitrogenProduction = -99;
            soilMineralNitrogenUptake = -99;
        }

        // Methods
        public double GrowSoilNitrogen()
        {
            if (soilMineralNitrogenAmount + soilNitrogenNetGrowth < 0)
            {
                throw new Exception("The soil mineral nitrogen amount cannot be negative.");
            }
            else
            {
                soilMineralNitrogenAmount = soilMineralNitrogenAmount + soilNitrogenNetGrowth;
            }
            return soilMineralNitrogenAmount;
        }
        public double CalculateSoilAvailableNitrogenProduction()
        {
            double f;
            double f_recov;
            double M;

            f_recov = fractionOfFertilizerRecovered;
            f = fertilizerAmount;
            M = netMineralizationRate;
            soilMineralNitrogenProduction = f_recov * f + M;

            return soilMineralNitrogenProduction;
        }
        public double CalculateSoilNitrogenNetGrowth()
        {
            double dsn;
            double p;
            double r;

            r = soilMineralNitrogenUptake;
            p = CalculateSoilAvailableNitrogenProduction();
            dsn = p - r;

            soilNitrogenNetGrowth = dsn;
            return soilNitrogenNetGrowth;
            /// ---------------------------------------------------------------------------------
        }
        public double[] CalculateSoilNitrogenRemoval(StripIntercrop ic)
        {
            double totalLightInterception;
            double[] uptakesFromSoil;
            double[] fractionsOfLightInterception;

            uptakesFromSoil = new double[ic.Crops.Length];
            fractionsOfLightInterception = new double[ic.Crops.Length];

            for (int i = 0; i < ic.Crops.Length; i++)
            {
                fractionsOfLightInterception[i] = ic.Crops[i].FractionOfLightIntercepted;
            }
            totalLightInterception = fractionsOfLightInterception.Sum();

            for(int i = 0; i < ic.Crops.Length;i++)
            {
                double availableNitrogenPool;
                double cropNitrogenDemandFromSoil;
                double fractionOfLightInterceptedByCrop;
                double fractionOfSoilNitrogenAvailableToCrop;
                double uptake;

                fractionOfLightInterceptedByCrop = fractionsOfLightInterception[i];
                if (fractionOfLightInterceptedByCrop == 0)
                {
                    fractionOfSoilNitrogenAvailableToCrop = 0;
                }
                else
                {
                    fractionOfSoilNitrogenAvailableToCrop = fractionOfLightInterceptedByCrop / totalLightInterception;
                }
                cropNitrogenDemandFromSoil = ic.Crops[i].CropNitrogen.CropNitrogenDemandFromSoil;
                availableNitrogenPool = soilMineralNitrogenAmount * fractionOfSoilNitrogenAvailableToCrop;
                if(availableNitrogenPool >= cropNitrogenDemandFromSoil)
                {
                    uptake = cropNitrogenDemandFromSoil;
                }
                else
                {
                    uptake = availableNitrogenPool;
                }
                uptakesFromSoil[i] = uptake;
                soilMineralNitrogenUptake = uptakesFromSoil.Sum();
            }

            return uptakesFromSoil;
        }
        public SoilMineralNitrogen InitialzeSoilMineralNitrogen()
        {
            fertilizerAmount = 0;
            soilMineralNitrogenAmount = initialNitrogenAmount;
            soilMineralNitrogenProduction = 0;
            soilMineralNitrogenUptake = 0;
            return this;
        }


        public double FertilizerAmount
        {
            get
            {
                return fertilizerAmount;
            }
            set
            {
                fertilizerAmount = value;
            }
        }
        public double FractionOfFertilizerRecovered
        {
            get
            {
                return fractionOfFertilizerRecovered;
            }
            set
            {
                fractionOfFertilizerRecovered = value;
            }
        }
        public double InitialNitrongenAmount
        {
            get
            {
                return initialNitrogenAmount;
            }
            set
            {
                initialNitrogenAmount = value;
            }
        }
        public double NetMineralizationRate
        {
            get
            {
                return netMineralizationRate;
            }
            set
            {
                netMineralizationRate = value;
            }
        }

        public double SoilMineralNitrogenAmount
        {
            get
            {
                return soilMineralNitrogenAmount;
            }
            set
            {
                soilMineralNitrogenAmount = value;
            }
        }
        public double SoilMineralNitrogenNetGrowth
        {
            get
            {
                return soilNitrogenNetGrowth;
            }
            set
            {
                soilNitrogenNetGrowth = value;
            }
        }

        public double SoilMineralNitrogenProduction
        {
            get
            {
                return soilMineralNitrogenProduction;
            }
            set
            {
                soilMineralNitrogenProduction = value;
            }
        }

        public double SoilMineralNitrogenUptake
        {
            get
            {
                return soilMineralNitrogenUptake;
            }
            set
            {
                soilMineralNitrogenUptake = value;
            }
        }
    }
}
