﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace M3_library
{
    public class CropFileReader
    {
        private double baseTemperature;
        private double coefficientACriticalNitrogenConcentration;
        private double coefficientAMaximumNitrogenConcentration;
        private double coefficientAMinimumNitrogenConcentration;
        private double coefficientBCriticalNitrogenConcentration;
        private double coefficientBMaximumNitrogenConcentration;
        private double coefficientBMinimumNitrogenConcentration;
        private double developmentRateDeclinePartitioningToLeaves;
        private double developmentRateNoPartitioningToLeaves;
        private double developmentRateFullPartitioningToStorageOrgansAndLeaves;
        private double developmentRateIncreasePartitioningToStorageOrgans;
        private double extinctionCoefficient;
        private double fractionCriticalToMaximumNitrogenConcentration;
        private double fractionMinimumToMaximumNitrogenConcentration;
        private double fractionOfNitrogenDemandFixed;
        private double initialCropHeight;
        private double initialLeafArea;
        private double maximumCropHeight;
        private double maximumCropNitrogenConcentrationEarlyGrowth;
        private double minimumTemperatureSenescence;
        private double partitioningFractionToLeavesBeforeDecline;
        private double radiationUseEfficiency;
        private double relativeGrowthRateHeight;
        private double slopeSenescenceTemperature;
        private double sowingDensity;
        private double specificLeafArea;
        private double temperatureSumSowingToEmergence;
        private double temperatureSumEmergenceToFlowering;
        private double temperatureSumFloweringToMaturity;

        // Constructor
        public CropFileReader()
        {
            baseTemperature = -99;
            developmentRateFullPartitioningToStorageOrgansAndLeaves = -99;
            developmentRateIncreasePartitioningToStorageOrgans = -99;
            fractionCriticalToMaximumNitrogenConcentration = -99;
            fractionMinimumToMaximumNitrogenConcentration = -99;
            initialCropHeight = -99;
            initialLeafArea = -99;
            radiationUseEfficiency = -99;
            sowingDensity = -99;
            specificLeafArea = -99;
            temperatureSumSowingToEmergence = -99;
            temperatureSumEmergenceToFlowering = -99;
            temperatureSumFloweringToMaturity = -99;
            maximumCropHeight = -99;
            relativeGrowthRateHeight = -99;
        }        

        // Methods
        public Crop ReadCropFromCSV(string filePath)
        {
            string line;
            string[] record;
            StreamReader sr;
            Crop crop;

            sr = new StreamReader(filePath);
            sr.ReadLine();
            line = sr.ReadLine();

            while (line != null)
            {
                double value;
                string symbol;
                record = line.Split(',');
                symbol = record[0];
                value = Convert.ToDouble(record[2]);

                switch (symbol)
                {
                    case "A_lv0":
                        {
                            initialLeafArea = value;
                            break;
                        }
                    case "coeffACrit":
                        {
                            coefficientACriticalNitrogenConcentration = value;
                            break;
                        }
                    case "coeffAMax":
                        {
                            coefficientAMaximumNitrogenConcentration = value;
                            break;
                        }
                    case "coeffAMin":
                        {
                            coefficientAMinimumNitrogenConcentration = value;
                            break;
                        }
                    case "coeffBCrit":
                        {
                            coefficientBCriticalNitrogenConcentration = value;
                            break;
                        }
                    case "coeffBMax":
                        {
                            coefficientBMaximumNitrogenConcentration = value;
                            break;
                        }
                    case "coeffBMin":
                        {
                            coefficientBMinimumNitrogenConcentration = value;
                            break;
                        }
                    case "fNCrit":
                        {
                            fractionCriticalToMaximumNitrogenConcentration = value;
                            break;
                        }
                    case "fNMin":
                        {
                            fractionMinimumToMaximumNitrogenConcentration = value;
                            break;
                        }
                    case "f_NFix":
                        {
                            fractionOfNitrogenDemandFixed = value;
                            break;
                        }
                    case "Nmax0":
                        {
                            maximumCropNitrogenConcentrationEarlyGrowth = value;
                            break;
                        }
                    case "rue":
                        {
                            radiationUseEfficiency = value;
                            break;
                        }
                    case "s_la":
                        {
                            specificLeafArea = value;
                            break;
                        }
                    case "k":
                        {
                            extinctionCoefficient = value;
                            break;
                        }
                    case "t_b":
                        {
                            baseTemperature = value;
                            break;
                        }
                    case "tsum_so_em":
                        {
                            temperatureSumSowingToEmergence = value;
                            break;
                        }
                    case "tsum_em_flo":
                        {
                            temperatureSumEmergenceToFlowering = value;
                            break;
                        }
                    case "tsum_flo_mat":
                        {
                            temperatureSumFloweringToMaturity = value;
                            break;
                        }
                    case "dev_1":
                        {
                            developmentRateDeclinePartitioningToLeaves = value;
                            break;
                        }
                    case "dev_2":
                        {
                            developmentRateNoPartitioningToLeaves = value;
                            break;
                        }
                    case "dev_y1":
                        {
                            developmentRateIncreasePartitioningToStorageOrgans = value;
                            break;
                        }
                    case "dev_y2":
                        {
                            developmentRateFullPartitioningToStorageOrgansAndLeaves = value;
                            break;
                        }
                    case "f_lv_0":
                        {
                            partitioningFractionToLeavesBeforeDecline = value;
                            break;
                        }
                    case "s_sen_t":
                        {
                            slopeSenescenceTemperature = value;
                            break;
                        }
                    case "t_min_sen":
                        {
                            minimumTemperatureSenescence = value;
                            break;                           
                        }
                    case "h_max":
                        {
                            maximumCropHeight = value;
                            break;
                        }
                    case "h_0":
                        {
                            initialCropHeight = value;
                            break;
                        }
                    case "rgrh":
                        {
                            relativeGrowthRateHeight = value;
                            break;
                        }
                    default:
                        break;
                }

                line = sr.ReadLine();
            }
            sr.Close();

            crop = new Crop();
            crop.CropNitrogen.MaximumNitrogenConcentrationEarlyGrowth = maximumCropNitrogenConcentrationEarlyGrowth;
            crop.CropNitrogen.CoefficientACriticalNitrogenConcentration = coefficientACriticalNitrogenConcentration;
            crop.CropNitrogen.CoefficientAMaximumNitrogenConcentration = coefficientAMaximumNitrogenConcentration;
            crop.CropNitrogen.CoefficientAMinimumNitrogenConcentration = coefficientAMinimumNitrogenConcentration;
            crop.CropNitrogen.CoefficientBCriticalNitrogenConcentration = coefficientBCriticalNitrogenConcentration;
            crop.CropNitrogen.CoefficientBMaximumNitrogenConcentration = coefficientBMaximumNitrogenConcentration;
            crop.CropNitrogen.CoefficientBMinimumNitrogenConcentration = coefficientBMinimumNitrogenConcentration;
            crop.CropNitrogen.FractionCriticalToMaximumNitrogenConcentration = fractionCriticalToMaximumNitrogenConcentration;
            crop.CropNitrogen.FractionMinimumToMaximumNitrogenConcentration = fractionMinimumToMaximumNitrogenConcentration;
            crop.CropNitrogen.FractionOfNitrogenDemandFixed = fractionOfNitrogenDemandFixed;
            crop.PartitioningFractionToLeavesBeforeDecline = partitioningFractionToLeavesBeforeDecline;
            crop.DevelopmentStateDeclinePartitioningToLeaves = developmentRateDeclinePartitioningToLeaves;
            crop.DevelopmentStateNoPartitioningToLeaves = developmentRateNoPartitioningToLeaves;
            crop.DevelopmentStateIncreasePartitioningToStorageOrgans = developmentRateIncreasePartitioningToStorageOrgans;
            crop.DevelopmentStateFullPartitioningToStorageOrgansAndLeaves = developmentRateFullPartitioningToStorageOrgansAndLeaves;
            crop.SowingDensity = sowingDensity;
            crop.Leaf.ExtinctionCoefficient = extinctionCoefficient;
            crop.Leaf.InitialLeafArea = initialLeafArea;
            crop.Leaf.MinimumTemperatureSenesence = minimumTemperatureSenescence;
            crop.Leaf.RadiationUseEfficiency = radiationUseEfficiency;
            crop.Leaf.SlopeSenesenceTemperature = slopeSenescenceTemperature;            
            crop.Leaf.SpecificLeafArea = specificLeafArea;
            crop.Stem.InitialShootHeight = initialCropHeight;
            crop.Stem.MaximumShootHeight = maximumCropHeight;
            crop.Stem.RelativeGrowthRateShootHeight = relativeGrowthRateHeight;
            crop.Phenology.BaseTemperature = baseTemperature;
            crop.Phenology.TemperatureSumSowingToEmergence = temperatureSumSowingToEmergence;
            crop.Phenology.TemperatureSumEmergenceToFlowering = temperatureSumEmergenceToFlowering;
            crop.Phenology.TemperatureSumFloweringToMaturity = temperatureSumFloweringToMaturity;
          
            return crop;
        }
    }
}
