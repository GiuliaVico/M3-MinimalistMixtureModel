﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace M3_library
{
    public class FarmerFileReader
    {
        public FarmerFileReader()
        {
        }

        // Methods
        public Farmer ReadFarmerFile(string filePath)
        {
            string line;
            string[] record;
            string workDirectory;
            Farmer f;
            StreamReader sr;
            List<string> cropParameterFilePathList;
            List<double> fertilizationAmountList;
            List<DateTime> fertilizationDateList;
            List<DateTime> harvestDateList;
            List<DateTime> sowingDateList;
            List<double> sowingDensityList;
            List<double> stripWidthList;

            cropParameterFilePathList = new List<string>();
            fertilizationAmountList = new List<double>();
            fertilizationDateList = new List<DateTime>();
            harvestDateList = new List<DateTime>();
            sowingDateList = new List<DateTime>();
            sowingDensityList = new List<double>();
            stripWidthList = new List<double>();

            sr = new StreamReader(filePath);
            workDirectory = Directory.GetCurrentDirectory();
            sr.ReadLine();
            line = sr.ReadLine();

            while (line != null)
            {
                CultureInfo provider;
                DateTime fertilizationDate;
                DateTime harvestDate;
                DateTime sowingDate;
                double fertilizationAmount;
                double sowingDensity;
                double stripWidth;
                string symbolAmount;
                string cropParameterFileName;
                string cropParameterFileDirectory;
                string cropFilePath;
                string dateFormat;

                provider = CultureInfo.InvariantCulture;
                dateFormat = "yyyy-MM-dd";

                record = line.Split(',');
                symbolAmount = record[0];
                switch (symbolAmount)
                {
                    case "date_sow":
                        sowingDate = DateTime.ParseExact(record[2], dateFormat, provider);
                        sowingDensity = Convert.ToDouble(record[6]);
                        harvestDate = Convert.ToDateTime(record[10]);
                        stripWidth = Convert.ToDouble(record[14]);
                        cropParameterFileDirectory = record[16];
                        if (cropParameterFileDirectory.Trim() == "")
                        {
                            string folderName;
                            folderName = @"Crop files\";
                            cropParameterFileDirectory = Path.Combine(workDirectory, folderName);
                        }
                        cropParameterFileName = record[17];
                        cropFilePath = cropParameterFileDirectory + cropParameterFileName;
                        cropParameterFilePathList.Add(cropFilePath);
                        harvestDateList.Add(harvestDate);
                        sowingDateList.Add(sowingDate);
                        sowingDensityList.Add(sowingDensity);
                        stripWidthList.Add(stripWidth);
                        break;
                    case "date_nfert":
                        fertilizationDate = DateTime.ParseExact(record[2], dateFormat, provider);
                        fertilizationAmount = Convert.ToDouble(record[6]);
                        fertilizationDateList.Add(fertilizationDate);
                        fertilizationAmountList.Add(fertilizationAmount);
                        break;
                    default:
                        break;
                }
                line = sr.ReadLine();
            }
            sr.Close();

            f = new Farmer();
            f.CropFilePaths = cropParameterFilePathList.ToArray();
            f.FertilizationAmounts = fertilizationAmountList.ToArray();
            f.FertilizationDates = fertilizationDateList.ToArray();
            f.HarvestDates = harvestDateList.ToArray();
            f.SowingDates = sowingDateList.ToArray();
            f.StripWidths = stripWidthList.ToArray();
            f.SowingDensities = sowingDensityList.ToArray();
            f.HarvestDates = harvestDateList.ToArray();
            return f;
        }

    }
}
