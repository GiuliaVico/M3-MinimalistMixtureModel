﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using M3_library;
using System.IO;

namespace M3_library
{
    public class SoilFileReader
    {

        private double fractionOfFertilizerRecovered;
        private double initialNitrogenAmount;
        private double netMineralizationRate;

        public SoilFileReader()
        {
            initialNitrogenAmount = -99;
        }


        public Soil ReadSoilFile(string soilFilePath)
        {
            Soil soil;
            StreamReader sr;
            string line;
            string[] record;

            soil = new Soil();
            soil.InitializeSoil();

            sr = new StreamReader(soilFilePath);
            sr.ReadLine();
            line = sr.ReadLine();

            while (line != null)
            {
                string symbolAmount;
                record = line.Split(',');
                symbolAmount = record[0];

                switch(symbolAmount)
                {
                    case "initial_n":
                        initialNitrogenAmount = Convert.ToDouble(record[2]);
                        break;
                    case "n_min_rate":
                        netMineralizationRate = Convert.ToDouble(record[2]);
                        break;
                    case "f_recov":
                        fractionOfFertilizerRecovered = Convert.ToDouble(record[2]);
                        break;
                    default:
                        break;
                }

                line = sr.ReadLine();
            }

            sr.Close();
            soil.SoilMineralNitrogen.InitialNitrongenAmount = initialNitrogenAmount;
            soil.SoilMineralNitrogen.NetMineralizationRate = netMineralizationRate;
            soil.SoilMineralNitrogen.FractionOfFertilizerRecovered = fractionOfFertilizerRecovered;
            return soil;
        }

        public double FractionOfFertilizerLost
        {
            get
            {
                return fractionOfFertilizerRecovered;
            }
            set
            {
                fractionOfFertilizerRecovered = value;
            }
        }
        public double InitialNitrogenAmount
        {
            get
            {
                return initialNitrogenAmount;
            }
            set
            {
                initialNitrogenAmount = value;
            }
        }

        public double NetMineralizationRate
        {
            get
            {
                return netMineralizationRate;
            }
            set
            {
                netMineralizationRate = value;
            }
        }
    }
}
