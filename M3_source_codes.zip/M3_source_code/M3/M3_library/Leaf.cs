﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Leaf
    {
        private double compressedLeafAreaIndex;
        private double extinctionCoefficient;
        private double initialLeafArea;
        private double leafAreaIndex;
        private double leafAreaIndexProduction;
        private double leafAreaIndexMortality;
        private double leafAreaIndexMortalityDueSenescence;
        private double leafMortality;
        private double leafMortalityDueSenescence;
        private double leafProduction;
        private double leafWeight;
        private double minimumTemperatureSenescence;
        private double radiationUseEfficiency;
        private double specificLeafArea;
        private double slopeSenescenceTemperature;

        // Constructor
        public Leaf()
        {
            compressedLeafAreaIndex = -99;
            leafAreaIndex = -99;
            leafProduction = -99;
            leafMortality = -99;
            leafWeight = -99;
            radiationUseEfficiency = -99;
            specificLeafArea = -99;
            initialLeafArea = -99;
        }

        // Methods
        public double CalculateCumulativeLeafAreaIndex(Crop c, double h)
        {
            /// -------------------------------------------------
            /// Leaf.CalculateCumulativeLeafAreaDensity()
            /// -------------------------------------------------
            /// 
            /// ---------------------------------------------------------------------
            /// 0. Description
            /// ---------------------------------------------------------------------
            /// The function Leaf.CalculateCumulativeLeafAreaDensity() calculates 
            /// the cumulative leaf area index above height h. The cumulative leaf
            /// area index above heigh h is calculated as:
            /// 
            /// L_cum(t,h) = L(t) * ( H(t) - h) / H(t)
            /// 
            /// h:          Height above the ground level [m]
            /// H(t):       Crop height at time t [m]
            /// L_cum(t):   Cumulative leaf area index above height h at time t.
            ///             [m2 leaf above height h] * [m-2 land covered]
            /// L(t):       Leaf area index at time t [m2 leaf] * [m-2 land]
            /// 
            /// ---------------------------------------------------------------------
            /// 1. Declare variables
            /// ---------------------------------------------------------------------
            double lai_cum;
            double lai;
            double htot;

            htot = c.Stem.ShootHeight;
            lai = c.Leaf.LeafAreaIndex;

            if (h < htot)
            {
                lai_cum = lai * (htot - h) / htot;
            }
            else
            {
                lai_cum = 0;
            }

            return lai_cum;
        }
        public Leaf CalculateLeafProduction(Crop c, DailyWeather dw)
        {
            double dev;
            double f_int;
            double g_N;
            double par_int;
            double f_lv;
            double f_par;
            double rad; 
            double rue;
            double g_B_l;
            PhysicalConstants py;
            /// ---------------------------------------------------------------------------
            /// 2. Initialize variables
            /// ---------------------------------------------------------------------------
            py = new PhysicalConstants();
            dev = c.Phenology.DevelopmentState;
            f_par = py.FractionOfPARInRadiation;
            rue = radiationUseEfficiency;
            f_int = c.FractionOfLightIntercepted;
            rad = dw.Radiation;
            g_N = c.CropNitrogen.CalculateGrowthReductionFactor(c);
            if (dev < 2)
            {
                c.CalculatePartitioningFractionToLeaves();
                f_lv = c.PartitioningFractionToLeaves;
                par_int = rad * f_int * f_par;
                g_B_l = g_N * rue * par_int * f_lv;
                leafProduction = g_B_l;
                leafAreaIndexProduction = leafProduction * specificLeafArea;
            }
            else
            {
                leafProduction = 0;
                leafAreaIndexProduction = 0;
            }
            return this;
            /// ---------------------------------------------------------------------------
        }
        public Leaf CalculateLeafMortality(Crop c, DailyWeather dw)
        {
            double dev;
            double m_B_L;
            double tmin_sen;
            double s_sen_t;
            double t_av;

            dev = c.Phenology.DevelopmentState;
            tmin_sen = minimumTemperatureSenescence;
            s_sen_t = slopeSenescenceTemperature;
            if (dev < 1)
            {
                leafMortality = 0;
                leafAreaIndexMortality = 0;
            }
            else
            {
                t_av = dw.Temperature;
                m_B_L = Math.Min(1, Math.Max(0, s_sen_t * (t_av - tmin_sen)));
                leafMortality = m_B_L * leafWeight;
                leafAreaIndexMortality = leafMortality * specificLeafArea;
            }

            return this;
        }
        public double CompressedLeafAreaIndex 
        {
            get
            {
                return compressedLeafAreaIndex;
            }
            set
            {
                compressedLeafAreaIndex = value;
            }
        }
        public double ExtinctionCoefficient
        {
            get
            {
                return extinctionCoefficient;
            }
            set
            {
                extinctionCoefficient = value;
             }
        }
        public double InitialLeafArea
        {
            get
            {
                return initialLeafArea;
            }
            set
            {
                initialLeafArea = value;
            }
        }
        public double LeafAreaIndex
        {
            get
            {
                return leafAreaIndex;
            }
            set
            {
                leafAreaIndex = value;
            }
        }
        public double LeafProduction
        {
            get
            {
                return leafProduction;
            }
            set
            {
                leafProduction = value;
            }
        }
        public double LeafMortality
        {
            get
            {
                return leafMortality;
            }
            set
            {
                leafMortality = value;
            }
        }
        public double LeafMortalityDueSenescence
        {
            get
            {
                return leafMortalityDueSenescence;
            }
            set
            {
                leafMortalityDueSenescence = value;
            }
        }
        public double LeafAreaIndexProduction
        {
            get
            {
                return leafAreaIndexProduction;
            }
            set
            {
                leafAreaIndexProduction = value;
            }
        }
        public double LeafAreaIndexMortality
        {
            get
            {
                return leafAreaIndexMortality;
            }
            set
            {
                leafAreaIndexMortality = value;
            }
        }
        public double LeafAreaIndexMortalityDueSenescence
        {
            get
            {
                return leafAreaIndexMortalityDueSenescence;
            }
            set
            {
                leafAreaIndexMortalityDueSenescence = value;
            }
        }
        public double LeafWeight
        {
            get
            {
                return leafWeight;
            }
            set
            {
                leafWeight = value;
            }
        }
        public double MinimumTemperatureSenesence
        {
            get
            {
                return minimumTemperatureSenescence;
            }
            set
            {
                minimumTemperatureSenescence = value;
            }
        }
        public double RadiationUseEfficiency
        {
            get
            {
                return radiationUseEfficiency;
            }
            set
            {
                radiationUseEfficiency = value;
            }
        }
        public double SlopeSenesenceTemperature
        {
            get
            {
                return slopeSenescenceTemperature;
            }
            set
            {
                slopeSenescenceTemperature = value;
            }
        }
        public double SpecificLeafArea
        {
            get
            {
                return specificLeafArea;
            }
            set
            {
                specificLeafArea = value;
            }
        }
    }
}
