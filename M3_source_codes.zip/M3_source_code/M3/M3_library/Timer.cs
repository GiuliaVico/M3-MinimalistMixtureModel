﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Timer
    {
        // Class variables
        private DateTime date;
        private DateTime startSimulationDate;
        private DateTime endSimulationDate;

        // Constructor
        public Timer()
        {
            startSimulationDate = new DateTime(1, 1, 1);
            endSimulationDate = new DateTime(9999, 12, 31);
            date = new DateTime(1, 1, 1);
        }

        // Methods
        public Timer AddDay()
        {
            date = date.AddDays(1);
            return this;
        }

        public Timer SubtractDay()
        {
            /// ---------------------------------------------------------------------------------
            /// Timer.SubtractDay()
            /// ---------------------------------------------------------------------------------
            /// The AddDay() function adds a day to the current date.
            /// ---------------------------------------------------------------------------------
            date = date.AddDays(-1);
            return this;
        }

        // Properties
        public DateTime Date
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
            }
        }
        public DateTime EndSimulationDate
        {
            get
            {
                return endSimulationDate;
            }
            set
            {
                endSimulationDate = value;
            }
        }
        public DateTime StartSimulationDate
        {
            get
            {
                return startSimulationDate;
            }
            set
            {
                startSimulationDate = value;
            }
        }
    }
}
