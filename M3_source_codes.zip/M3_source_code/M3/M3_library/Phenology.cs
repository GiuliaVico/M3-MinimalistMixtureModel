﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Phenology
    {
        private double baseTemperature;
        private DateTime sowingDate;
        private double developmentState;
        private double temperatureSumFloweringToMaturity;
        private double temperatureSumFromFlowering;
        private double temperatureSumEmergenceToFlowering;
        private double temperatureSumFromEmergence;
        private double temperatureSumFromSowing;
        private double temperatureSumSowingToEmergence;

        // Constructor
        public Phenology()
        {

            baseTemperature = -99;
            developmentState = -99;
            temperatureSumFromEmergence = -99;
            temperatureSumSowingToEmergence = -99;
            temperatureSumEmergenceToFlowering = -99;
            temperatureSumFloweringToMaturity = -99;
            temperatureSumFromSowing = -99;
        }

        // Methods
        public Phenology CalculateDevelopmentState(Timer t, WeatherStation w)
        {
            double dev;
            double tsum_em;
            double tsum_em_flo;
            double tsum_flo_mat;

            CalculateTemperatureSumFromSowing(t, w);
            CalculateTemperatureSumFromEmergence(t, w);
            CalculateTemperatureSumFromFlowering(t, w);
            tsum_em = temperatureSumFromEmergence;
            tsum_em_flo = temperatureSumEmergenceToFlowering;
            tsum_flo_mat = temperatureSumFloweringToMaturity;
            if (tsum_em <= 0)
            {
                dev = 0;
            }
            else if (tsum_em > 0 && tsum_em <= tsum_em_flo)
            {
                dev = tsum_em / tsum_em_flo;
            }
            else if (tsum_em > tsum_em_flo & tsum_em <= tsum_em_flo + tsum_flo_mat)
            {
                dev = 1 + (tsum_em - tsum_em_flo) / tsum_flo_mat;
            }
            else
            {
                dev = 2;
            }

            developmentState = dev;
            return this;
        }
        public Phenology CalculateTemperatureSumFromSowing(Timer t, WeatherStation w)
        {
            double tsum;
            double tb;
            DateTime currentDate;

            currentDate = t.Date;
            tb = baseTemperature;
            tsum = 0;

            for (int i = 0; i < w.WeatherRecords.Length; i++)
            {
                DateTime date;
                DailyWeather dw;
                double tmin;
                double tmax;
                double tav;
                double teff;

                dw = w.WeatherRecords[i];
                date = dw.Date;

                if (date > sowingDate && date <= currentDate)
                {
                    tmin = dw.MinimumTemperature;
                    tmax = dw.MaximumTemperature;
                    tav = (tmin + tmax) / 2;
                    teff = Math.Max(tav - tb, 0);
                    tsum = tsum + teff;
                }
                else
                {
                }
            }
            temperatureSumFromSowing = tsum;
            return this;
        }
        public Phenology CalculateTemperatureSumFromEmergence(Timer t, WeatherStation w)
        {
            temperatureSumFromEmergence = Math.Max(0,temperatureSumFromSowing - temperatureSumSowingToEmergence);

            return this;
        }
        public Phenology CalculateTemperatureSumFromFlowering(Timer t, WeatherStation w)
        {
            temperatureSumFromFlowering = Math.Max(0, temperatureSumFromEmergence - temperatureSumEmergenceToFlowering);
            return this;           
        }

        // Properties
        public double BaseTemperature
        {
            get
            {
                return baseTemperature;
            }
            set
            {
                baseTemperature = value;
            }
        }
        public double DevelopmentState
        {
            get
            {
                return developmentState;
            }
            set
            {
                developmentState = value;
            }
        }
        public DateTime SowingDate
        {
            get
            {
                return sowingDate;
            }
            set
            {
                sowingDate = value;
            }
        }
        public double TemperatureSumFloweringToMaturity
        {
            get
            {
                return temperatureSumFloweringToMaturity;
            }
            set
            {
                temperatureSumFloweringToMaturity = value;
            }
        }
        public double TemperatureSumEmergenceToFlowering
        {
            get
            {
                return temperatureSumEmergenceToFlowering;
            }
            set
            {
                temperatureSumEmergenceToFlowering = value;
            }
        }
        public double TemperatureSumFromEmergence
        {
            get
            {
                return temperatureSumFromEmergence;
            }
            set
            {
                temperatureSumFromEmergence = value;
            }
        }
        public double TemperatureSumFromFlowering
        {
            get
            {
                return temperatureSumFromFlowering;
            }
            set
            {
                temperatureSumFromFlowering = value;
            }
        }
        public double TemperatureSumFromSowing
        {
            get
            {
                return temperatureSumFromSowing;
            }
            set
            {
                temperatureSumFromSowing = value;
            }
        }
        public double TemperatureSumSowingToEmergence
        {
            get
            {
                return temperatureSumSowingToEmergence;
            }
            set
            {
                temperatureSumSowingToEmergence = value;
            }
        }
    }
}
