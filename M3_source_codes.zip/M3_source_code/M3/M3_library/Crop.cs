﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Crop
    {
        // Class variables
        private int cropID;
        private CropNitrogen cropNitrogen;
        private double abovegroundDryWeight;
        private double abovegroundBiomassProduction;
        private double abovegroundBiomassMortality;
        private double developmentStateDeclinePartitioningToLeaves;
        private double developmentStateFullPartitioningToStorageOrgansAndLeaves;
        private double developmentStateIncreasePartitioningToStorageOrgans;
        private double developmentStateNoPartitioningToLeaves;
        private double fractionOfLightInterception;
        private DateTime harvestDate;
        private bool isCropEmerged;
        private bool isCropHarvested;
        private Leaf leaf;
        private double partitioningFractionToLeaves;
        private double partitioningFractionToStorageOrgans;
        private double partitioningFractionToLeavesBeforeDecline;
        private Phenology phenology;
        private double sowingDensity;
        private double stripWidth;
        private Stem stem;
        private StorageOrgan storageOrgan;

        // Constructor
        public Crop()
        {
            /// -------------------------------------------------
            /// Crop.Crop()
            /// -------------------------------------------------
            /// 
            /// The Crop() constructor declares a Crop object 
            /// and initializes it.
            /// ------------------------------------------------
            abovegroundDryWeight = -99;
            isCropEmerged = false;
            isCropHarvested = false;
            partitioningFractionToLeavesBeforeDecline = -99;
            developmentStateDeclinePartitioningToLeaves = -99;
            developmentStateNoPartitioningToLeaves = -99;
            stripWidth = -99;
            sowingDensity = -99;
            cropNitrogen = new CropNitrogen();
            leaf = new Leaf();
            phenology = new Phenology();
            stem = new Stem();
            storageOrgan = new StorageOrgan();
        }

        // Methods
        public Crop CalculateCropProduction(DailyWeather dw)
        {
            double dev;
            double interceptedPAR;
            PhysicalConstants pc;

            pc = new PhysicalConstants();
            dev = phenology.DevelopmentState;

            if (dev < 2)
            {
                interceptedPAR = pc.FractionOfPARInRadiation * fractionOfLightInterception * dw.Radiation;
                abovegroundBiomassProduction = cropNitrogen.NitrogenGrowthReductionFactor * leaf.RadiationUseEfficiency * interceptedPAR;
            }
            else
            {
                abovegroundBiomassProduction = 0;
            }

            return this;
        }
        public Crop CalculatePartitioningFractionToLeaves()
        {
            double f_lv;
            double dev_1;
            double dev_2;
            double f_lv_0;
            double dev;

            dev = phenology.DevelopmentState;
            dev_1 = developmentStateDeclinePartitioningToLeaves;
            dev_2 = developmentStateNoPartitioningToLeaves;
            f_lv_0 = partitioningFractionToLeavesBeforeDecline;

            if (dev == 0)
            {
                f_lv = 0;
            }
            else if (dev > 0 && dev <= dev_1)
            {
                f_lv = f_lv_0;
            }
            else if (dev > dev_1 && dev <= dev_2)
            {
                f_lv = f_lv_0 * (dev_2 - dev) / (dev_2 - dev_1);
            }
            else
            {
                f_lv = 0;
            }
            partitioningFractionToLeaves = f_lv;

            return this;
        }
        public Crop CalculatePartitioningFactorToStorageOrgans()
        {
            double f_lv;
            double f_so;
            double dev;
            double dev_y1;
            double dev_y2;

            dev = phenology.DevelopmentState;
            dev_y1 = developmentStateIncreasePartitioningToStorageOrgans;
            dev_y2 = developmentStateFullPartitioningToStorageOrgansAndLeaves;
            f_lv = partitioningFractionToLeaves;

            if (dev == 0)
            {
                f_so = 0;
            }
            else if (dev > 0 && dev <= dev_y1)
            {
                f_so = 0;
            }
            else if (dev > dev_y1 && dev <= dev_y2)
            {
                f_so = (1 - f_lv) * (dev - dev_y1) / (dev_y2 - dev_y1);
            }
            else if (dev > dev_y2 && dev < 2)
            {
                f_so = 1 - f_lv;
            }
            else
            {
                f_so = 0;
            }

            partitioningFractionToStorageOrgans = f_so;
            return this;
        }
        public Crop CalculateCropGrowth(StripIntercrop ic, Soil s, Timer t, WeatherStation w, DailyWeather dw)
        {
            double[] nitrogenUptakesFromSoil;

            CalculateCropProduction(dw);
            CalculatePartitioningFractionToLeaves();
            CalculatePartitioningFactorToStorageOrgans();
            leaf.CalculateLeafProduction(this, dw);
            leaf.CalculateLeafMortality(this, dw);
            storageOrgan.CalculateStorageOrganProduction(this, dw);
            abovegroundBiomassMortality = leaf.LeafMortality;
            stem.CalculateShootHeightGrowth(this, dw);
            cropNitrogen.CalculateMaximumNitrogenConcentration(ic, this);
            cropNitrogen.CalculateCritcialNitrogenConcentration(ic, this);
            cropNitrogen.CalculateMinimumNitrogenConcentration(ic, this);
            cropNitrogen.CalculateCropNitrogenDemand(ic, this);
            cropNitrogen.CalculateCropNitrogenDemandFromSoil();
            nitrogenUptakesFromSoil = s.SoilMineralNitrogen.CalculateSoilNitrogenRemoval(ic);
            for (int i = 0; i < ic.Crops.Length; i++)
            {
                ic.Crops[i].CropNitrogen.NitrogenUptakeFromSoil = nitrogenUptakesFromSoil[i];
            }
            cropNitrogen.NitrogenUptakeFromSoil = nitrogenUptakesFromSoil[this.CropID];
            cropNitrogen.CalculateCropNitrogenFixed();
            cropNitrogen.CalculateGrowthReductionFactor(this);
            cropNitrogen.CalculateCropNitrogenGrowth(this);
            phenology.CalculateDevelopmentState(t, w);
            return this;
        }
        public Crop EmergeCrop(StripIntercrop ic)
        {
            double A_lv0;
            double h0;
            double N_max_conc;
            double N_sow;
            double s_la;

            A_lv0 = leaf.InitialLeafArea;
            h0 = stem.InitialShootHeight;
            N_sow = sowingDensity;
            s_la = leaf.SpecificLeafArea;

            leaf.LeafAreaIndex = N_sow * A_lv0;
            leaf.LeafWeight = N_sow * A_lv0 / s_la;
            stem.ShootHeight = h0;
            abovegroundDryWeight = leaf.LeafWeight;
            N_max_conc = cropNitrogen.CalculateMaximumNitrogenConcentration(ic, this);
            cropNitrogen.CropNitrogenAmount = N_max_conc * N_sow * A_lv0 / s_la;
            cropNitrogen.CalculateCropNitrogenConcentration(this);

            return this;
        }
        public Crop GrowCrop()
        {
            abovegroundDryWeight = abovegroundDryWeight + abovegroundBiomassProduction - abovegroundBiomassMortality;
            leaf.LeafAreaIndex = leaf.LeafAreaIndex + leaf.LeafAreaIndexProduction - leaf.LeafAreaIndexMortality;
            leaf.LeafWeight = leaf.LeafWeight + leaf.LeafProduction - leaf.LeafMortality;
            stem.ShootHeight = stem.ShootHeight + stem.ShootHeightGrowth;
            storageOrgan.StorageOrganWeight = storageOrgan.StorageOrganWeight + storageOrgan.StorageOrganProduction;
            cropNitrogen.GrowCropNitrogen(this);
            return this;
        }
        public Crop HarvestCrop()
        {
            leaf.LeafAreaIndex = 0;
            leaf.LeafWeight = 0;
            stem.ShootHeight = 0;
            storageOrgan.StorageOrganWeight = 0;
            abovegroundDryWeight = 0;
            isCropHarvested = true;

            return this;
        }
        public Crop InitializeCrop()
        {
            abovegroundDryWeight = 0;
            abovegroundBiomassProduction = 0;
            abovegroundBiomassMortality = 0;
            leaf.LeafAreaIndex = 0;
            leaf.LeafWeight = 0;
            leaf.LeafProduction = 0;
            leaf.LeafMortality = 0;
            phenology.DevelopmentState = 0;
            phenology.TemperatureSumFromSowing = 0;
            stem.ShootHeight = 0;
            stem.ShootHeightGrowth = 0;
            storageOrgan.StorageOrganProduction = 0;
            storageOrgan.StorageOrganWeight = 0;

            cropNitrogen.InitializeCropNitrogen();
            return this;
        }

        // Properties
        public double AbovegroundBiomassProduction
        {
            get
            {
                return abovegroundBiomassProduction;
            }
            set
            {
                abovegroundBiomassProduction = value;
            }
        }
        public double AbovegroundBiomassMortality
        {
            get
            {
                return abovegroundBiomassMortality;
            }
            set
            {
                abovegroundBiomassMortality = value;
            }
        }
        public double AbovegroundDryWeight
        {
            get
            {
                return abovegroundDryWeight;
            }
            set
            {
                abovegroundDryWeight = value;
            }
        }
        public int CropID
        {
            get
            {
                return cropID;
            }
            set
            {
                cropID = value;
            }
        }
        public CropNitrogen CropNitrogen
        {
            get
            {
                return cropNitrogen;
            }
            set
            {
                cropNitrogen = value;
            }
        }
        public double DevelopmentStateNoPartitioningToLeaves
        {
            get
            {
                return developmentStateNoPartitioningToLeaves;
            }
            set
            {
                developmentStateNoPartitioningToLeaves = value;
            }
        }
        public double DevelopmentStateDeclinePartitioningToLeaves
        {
            get
            {
                return developmentStateDeclinePartitioningToLeaves;
            }
            set
            {
                developmentStateDeclinePartitioningToLeaves = value;
            }
        }
        public double DevelopmentStateIncreasePartitioningToStorageOrgans
        {
            get
            {
                return developmentStateIncreasePartitioningToStorageOrgans;
            }
            set
            {
                developmentStateIncreasePartitioningToStorageOrgans = value;
            }
        }
        public double DevelopmentStateFullPartitioningToStorageOrgansAndLeaves
        {
            get
            {
                return developmentStateFullPartitioningToStorageOrgansAndLeaves;
            }
            set
            {
                developmentStateFullPartitioningToStorageOrgansAndLeaves = value;
            }
        }
        public double FractionOfLightIntercepted
        {
            get
            {
               return fractionOfLightInterception;
            }
            set
            {
                fractionOfLightInterception = value;
            }
        }
        public DateTime HarvestDate
        {
            get
            {
                return harvestDate;
            }
            set
            {
                harvestDate = value;
            }
        }
        public bool IsCropEmerged
        {
            get
            {
                return isCropEmerged;
            }
            set
            {
                isCropEmerged = value;
            }
        }
        public bool IsCropHarvested
        {
            get
            {
                return isCropHarvested;
            }
            set
            {
                isCropHarvested = value;
            }
        }
        public double PartitioningFractionToLeaves
        {
            get
            {
                return partitioningFractionToLeaves;
            }
            set
            {
                partitioningFractionToLeaves = value;
            }
        }
        public double PartitioningFractionToLeavesBeforeDecline
        {
            get
            {
                return partitioningFractionToLeavesBeforeDecline;
            }
            set
            {
                partitioningFractionToLeavesBeforeDecline = value;
            }
        }
        public Leaf Leaf
        {
            get
            {
                return leaf;
            }
            set
            {
                leaf = value;
            }
        }
        public double PartitioningFractionToStorageOrgans
        {
            get
            {
                return partitioningFractionToStorageOrgans;
            }
            set
            {
                partitioningFractionToStorageOrgans = value;
            }
        }
        public Phenology Phenology
        {
            get
            {
                return phenology;
            }
            set
            {
                phenology = value;
            }
        }
        public double SowingDensity
        {
            get
            {
                return sowingDensity;
            }
            set
            {
                sowingDensity = value;
            }
        }
        public Stem Stem
        {
            get
            {
                return stem;
            }
            set
            {
                stem = value;
            }
        }
        public StorageOrgan StorageOrgan
        {
            get
            {
                return storageOrgan;
            }
            set
            {
                storageOrgan = value;
            }
        }
        public double StripWidth
        {
            get
            {
                return stripWidth;
            }
            set
            {
                stripWidth = value;
            }
        }
    }
}
