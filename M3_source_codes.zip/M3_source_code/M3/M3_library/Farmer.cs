﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Farmer
    {
        /// --------------------------------------------------------------------------
        /// <summary>
        /// --------------------------------------------------------------------------
        /// File name:      Farmer.cs
        /// Author:         Herman Berghuijs
        /// Date:           October 3 2019
        /// --------------------------------------------------------------------------
        ///
        /// --------------------------------------------------------------------------
        /// 1. Purpose
        /// --------------------------------------------------------------------------       
        /// The file Farmer.cs contains the class Farmer. The class contains values of
        /// all management parameters. The Farmer class also contains methods that 
        /// conduct a certain management practice. Finally, the farmer class contains
        /// properties.
        /// -------------------------------------------------------------------------
        /// 2. Description of class variables
        /// -------------------------------------------------------------------------
        /// Each subsection of section 2 contains the description of a class variable.
        /// 
        ///     2.1 fertilzationDates:
        ///         Data type:      DateTime array
        ///         Variable type:  External management data
        ///         Meaning:        Dates of each fertilization event
        ///         Unit:           Not applicable
        ///         
        ///     2.2 harvestDates:
        ///         Data type:      DateTime array
        ///         Variable type:  External management data
        ///         Meaning:        Contains  harvest dates for each crop species in 
        ///                         an intercrop.
        ///         Unit:           Not applicable            
        /// 
        ///     2.2 sowingDates:
        ///         Data type:      DateTime array
        ///         Variable type:  External management data
        ///         Meaning:        Contains sowin dates for each crop species in 
        ///                         an intercrop.
        ///         Unit:           Not applicable            
        /// 
        ///     2.3 fertilizationAmounts
        ///         Data type:      Double array
        ///         Variable type:  External management data
        ///         Meaning:        Contains the amount of nitrogen in the fertilizer
        ///                         that is applied at each fertilization event.
        ///         Unit:           [kg N] * [m^-2]
        ///         
        ///     2.4 sowingDensities
        ///         Data type:      Double array
        ///         Variable type:  External management data
        ///         Meaning:        Sowing density of each crop in an intercrop.
        ///         Unit:           [seed] * [m^-2]        
        ///        
        ///     2.5 stripWidths
        ///         Data type:      Double array
        ///         Variable type:  External management data
        ///         Meaning:        Contains the strip width of each species in a
        ///                         strip intercrop.
        ///         Unit:           [m]
        /// 
        ///     2.6 cropFileDirectories
        ///         Data type:      String array
        ///         Variable type:  Location data
        ///         Meaning:        Contains the direcetories of all crop parameter
        ///                         files of the crop in an intercrop.
        ///         Unit:           Not applicable
        ///       
        ///     2.7 cropFileNames
        ///         Data type:      String array
        ///         Variable type:  Location data
        ///         Meaning:        Contains the file names of all crop parameter
        ///                         files of the crop in an intercrop.
        ///         Unit:           Not applicable        
        ///         
        ///     2.8 cropFileDirectories
        ///         Data type:      String array
        ///         Variable type:  Location data
        ///         Meaning:        Contains the directories of all crop parameter
        ///                         files of the crop in an intercrop.
        ///         Unit:           Not applicable       
        ///         
        ///     2.9 cropFilePaths
        ///         Data type:      String array
        ///         Variable type:  Location data
        ///         Meaning:        Contains the file paths of all crop parameter
        ///                         files of the crop in an intercrop.
        ///         Unit:           Not applicable      
        /// --------------------------------------------------------------------------           
        /// 3. Method description
        /// --------------------------------------------------------------------------  
        /// Section 3 contains a description of all constructors and functions in the
        /// Farmer class
        /// 
        ///     3.1 Farmer()
        ///         Type:       Constructor
        ///         Purpose:    Initializes a Farmer object
        ///         Input:      None
        ///         Output:     Farmer
        ///         
        ///     3.2 Harverst()
        ///         Type:       Function
        ///         Purpose:    Harvests a crop
        ///         Input:      Crop
        ///         Output:     Crop
        /// --------------------------------------------------------------------------  
        /// <summary>
        private string[] cropFileDirectories;
        private string[] cropFileNames;
        private string[] cropParameterFilePaths;
        private double[] fertilizationAmounts;
        private DateTime[] fertilizationDates;
        private DateTime[] harvestDates;
        private double[] irrigationAmounts;
        private DateTime[] irrigationDates;
        private double[] stripWidths;
        private DateTime[] sowingDates;
        private double[] sowingDensities;

        public Farmer()
        {
            stripWidths = new double[] { -99 };
            fertilizationAmounts = new double[] { -99 };
            fertilizationDates = new DateTime[] { new DateTime(1, 1, 1) };
            irrigationAmounts = new double[] { -99 };
            irrigationDates = new DateTime[] { new DateTime(1, 1, 1) };
            sowingDates = new DateTime[] { new DateTime(1, 1, 1) };
            harvestDates = new DateTime[] { new DateTime(1, 1, 1) };
        }
        public Crop Harvest(Crop c)
        {
            c = c.HarvestCrop();
            return c;
        }

        public double[] FertilizationAmounts
        {
            get
            {
                return fertilizationAmounts;
            }
            set
            {
                fertilizationAmounts = value;
            }
        }

        public DateTime[] FertilizationDates
        {
            get
            {
                return fertilizationDates;
            }
            set
            {
                fertilizationDates = value;
            }
        }
        public double[] IrrigationAmounts
        {
            get
            {
                return irrigationAmounts;
            }
            set
            {
                irrigationAmounts = value;
            }
        }

        public DateTime[] IrrigationDates
        {
            get
            {
                return irrigationDates;
            }
            set
            {
                irrigationDates = value;
            }
        }

        public DateTime[] SowingDates
        {
            get
            {
                return sowingDates;
            }
            set
            {
                sowingDates = value;
            }
        }

        public double[] SowingDensities
        {
            get
            {
                return sowingDensities;
            }
            set
            {
                sowingDensities = value;
            }
        }

        public double[] StripWidths
        {
            get
            {
                return stripWidths;
            }
            set
            {
                stripWidths = value;
            }
        }

        public string[] CropFilePaths
        {
            get
            {
                return cropParameterFilePaths;
            }
            set
            {
                cropParameterFilePaths = value;
            }
        }

        public string[] CropFileNames
        {
            get
            {
                return cropFileNames;
            }
            set
            {
                cropFileNames = value;
            }
        }

        public string[] CropFileDirectories
        {
            get
            {
                return cropFileDirectories;
            }
            set
            {
                cropFileDirectories = value;
            }
        }

        public DateTime[] HarvestDates
        {
            get
            {
                return harvestDates;
            }
            set
            {
                harvestDates = value;
            }
        }
    }
}
