﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Soil
    {
        private SoilMineralNitrogen soilMineralNitrogen;

        // Constructor
        public Soil()
        {
            soilMineralNitrogen = new SoilMineralNitrogen();
        }

        // Methods
        public Soil InitializeSoil()
        {
            soilMineralNitrogen = soilMineralNitrogen.InitialzeSoilMineralNitrogen();
            return this;
        }

        // Properties
        public SoilMineralNitrogen SoilMineralNitrogen
        {
            get
            {
                return soilMineralNitrogen;
            }
            set
            {
                soilMineralNitrogen = value;
            }
        }
    }
}
