﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class DailyWeather
    {
        private int dayOfMonth;
        private int dayOfYear;
        private DateTime date;
        private double maximumTemperature;
        private double minimumTemperature;
        private int month;
        private double temperature;
        private double radiation;
        private int weatherStationID;
        private int year;

        public DailyWeather()
        {
            weatherStationID = -99;
            date = new DateTime(9999, 1, 1);
            dayOfYear = date.DayOfYear;
            year = date.Year;
            month = date.Month;
            dayOfMonth = date.Day;
            minimumTemperature = -99.0;
            maximumTemperature = -99.0;
            radiation = -99.0;
            temperature = -99.0;
        }
        public DateTime Date
        {
            get
            {
                return date;
            }
            set
            {
                date = value;
                year = date.Year;
                month = date.Month;
                dayOfMonth = date.Day;
                dayOfYear = date.DayOfYear;
            }
        }

        public int Year
        {
            get
            {
                return year;
            }
            set
            {
                year = value;
                date = new DateTime(year,month,dayOfMonth);
            }
        }
        public int Month
        {
            get
            {
                return month;
            }
            set
            {
                month = value;
                date = new DateTime(year, month, dayOfMonth);
            }
        }
        public int DayOfMonth
        {
            get
            {
                return dayOfMonth;
            }
            set
            {
                dayOfMonth = value;
                date = new DateTime(year, month, dayOfMonth);
            }
        }


        public int DayOfYear
        {
            get
            {
                return dayOfYear;
            }
            set
            {
                dayOfYear = value;
                date = new DateTime(year, 1, 1).AddDays(dayOfYear-1);
            }
        }

        public double MaximumTemperature
        {
            get
            {
                return maximumTemperature;
            }
            set
            {
                maximumTemperature = value;
                temperature = (minimumTemperature + maximumTemperature) / 2;
            }
        }
        public double MinimumTemperature
        {
            get
            {
                return minimumTemperature;
            }
            set
            {
                minimumTemperature = value;
                temperature = (minimumTemperature + maximumTemperature) / 2;
            }
        }
        public double Radiation
        {
            get
            {
                return radiation;
            }
            set
            {
                radiation = value;
            }
        }
        public double Temperature
        {
            get
            {
                return temperature;
            }
            set
            {
                temperature = value;
            }
        }
        public int WeatherStationID
        {
            get
            {
                return weatherStationID;
            }
            set
            {
                weatherStationID = value;
            }
        }
    }
}
