﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3_library
{
    public class Stem
    {
        // Class variables
        private double shootHeightGrowth;
        private double shootHeight;
        private double initialShootHeight;
        private double maximumShootHeight;
        private double relativeGrowthRateShootHeight;

        // Constructor
        public Stem()
        {
            shootHeight = -99;
            shootHeightGrowth = -99;
            initialShootHeight = -99;
            maximumShootHeight = -99;
        }

        // Methods
        public Stem CalculateShootHeightGrowth(Crop c, DailyWeather dw)
        {

            double g_h;
            double h;
            double hmax;
            double rgrh;
            double T;
            double Tb;
            double T_eff;

            h = c.Stem.ShootHeight;
            hmax = c.Stem.MaximumShootHeight;
            rgrh = c.Stem.RelativeGrowthRateShootHeight;
            T = dw.Temperature;
            Tb = c.Phenology.BaseTemperature;

            T_eff = Math.Max(0, T - Tb);
            g_h = h * rgrh * (1 - h / hmax) * T_eff;

            c.Stem.ShootHeightGrowth = g_h;
            return c.Stem;
            /// ---------------------------------------------------------------------------------
        }

        // Properties
        public double ShootHeight
        {
            get
            {
                return shootHeight;
            }
            set
            {
                shootHeight = value;
            }
        }

        public double ShootHeightGrowth
        {
            get
            {
                return shootHeightGrowth;
            }
            set
            {
                shootHeightGrowth = value;
            }
        }
        public double InitialShootHeight
        {
            get
            {
                return initialShootHeight;
            }
            set
            {
                initialShootHeight = value;
            }
        }


        public double MaximumShootHeight
        {
            get
            {
                return maximumShootHeight;
            }
            set
            {
                maximumShootHeight = value;
            }
        }

        public double RelativeGrowthRateShootHeight
        {
            get
            {
                return relativeGrowthRateShootHeight;
            }
            set
            {
                relativeGrowthRateShootHeight = value;
            }
        }
    }
}
