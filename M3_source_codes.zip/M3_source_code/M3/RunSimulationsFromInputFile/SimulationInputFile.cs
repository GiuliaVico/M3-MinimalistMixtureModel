﻿using System;
using System.Collections.Generic;
using System.IO;

namespace RunSimulationsFromInputFile
{
    public class SimulationInputFile
    {
        private string simulationInputFileDirectory;
        private string simulationInputFileName;
        private string simulationInputFilePath;
        private string[] farmerFileDirectories;
        private string[] farmerFileNames;
        private string[] farmerFilePaths;
        private string[] outputFileDirectories;
        private string[] outputFileNames;
        private string[] outputFilePaths;
        private int[] runIDs;
        private string[] soilFileDirectories;
        private string[] soilFileNames;
        private string[] soilFilePaths;
        private string[] weatherFileDirectories;
        private string[] weatherFileNames;
        private string[] weatherFilePaths;
        private string[] weatherStationFileDirectories;
        private string[] weatherStationFileNames;
        private string[] weatherStationFilePaths;
        private int[] weatherStationIDs;

        public SimulationInputFile ReadSimulationInputFile()
        {
            List<int> runIDList;
            List<string> outputFileDirectoryList;
            List<string> outputFileNameList;
            List<string> outputFilePathList;
            List<string> farmerFileDirectoryList;
            List<string> farmerFileNameList;
            List<string> farmerFilePathList;
            List<string> soilFileDirectoryList;
            List<string> soilFileNameList;
            List<string> soilFilePathList;
            List<int> weatherStationIDList;
            List<string> weatherStationFileDirectoryList;
            List<string> weatherStationFileNameList;
            List<string> weatherStationFilePathList;
            List<string> weatherFileDirectoryList;
            List<string> weatherFileNameList;
            List<string> weatherFilePathList;

            runIDList = new List<int>();
            outputFileDirectoryList = new List<string>();
            outputFileNameList = new List<string>();
            outputFilePathList = new List<string>();
            farmerFileDirectoryList = new List<string>();
            farmerFileNameList = new List<string>();
            farmerFilePathList = new List<string>();
            soilFileDirectoryList = new List<string>();
            soilFileNameList = new List<string>();
            soilFilePathList = new List<string>();
            weatherStationIDList = new List<int>();
            weatherStationFileDirectoryList = new List<string>();
            weatherStationFilePathList = new List<string>();
            weatherStationFileNameList = new List<string>();
            weatherFileDirectoryList = new List<string>();
            weatherFileNameList = new List<string>();
            weatherFilePathList = new List<string>();

            StreamReader sr;
            string line;
            char separator;

            separator = ',';
            sr = new StreamReader(simulationInputFilePath);
            line = sr.ReadLine();
            line = sr.ReadLine();

            while(line!=null)
            {
                string[] record;
                int runID;
                string farmerFileDirectory;
                string farmerFileName;
                string farmerFilePath;
                string outputFileDirectory;
                string outputFileName;
                string outputFilePath;
                string soilFileDirectory;
                string soilFileName;
                string soilFilePath;
                int weatherStationID;
                string weatherStationFileDirectory;
                string weatherStationFileName;
                string weatherStationFilePath;
                string weatherFileName;
                string weatherFileDirectory;
                string weatherFilePath;
                string workDirectory;

                record = line.Split(separator);
                runID = Convert.ToInt32(record[0]);
                outputFileDirectory = record[1];
                outputFileName = record[2];
                farmerFileDirectory = record[3];
                farmerFileName = record[4];
                soilFileDirectory = record[5];
                soilFileName = record[6];
                weatherStationID = Convert.ToInt32(record[7]);
                weatherStationFileDirectory = record[8];
                weatherStationFileName = record[9];
                weatherFileDirectory = record[10];
                weatherFileName = record[11];
                workDirectory = Directory.GetCurrentDirectory();

                if(outputFileDirectory.Trim() == "")
                {
                    string folderName;
                    folderName = @"Output files\";
                    outputFileDirectory = Path.Combine(workDirectory,folderName);
                }
                outputFilePath = Path.Combine(outputFileDirectory, outputFileName);

                if (farmerFileDirectory.Trim() == "")
                {
                    string folderName;
                    folderName = @"Farmer files\";
                    farmerFileDirectory = Path.Combine(workDirectory, folderName);
                }
                farmerFilePath = Path.Combine(farmerFileDirectory, farmerFileName);

                if (soilFileDirectory.Trim() == "")
                {
                    string folderName;
                    folderName = @"Soil files\";
                    soilFileDirectory = Path.Combine(workDirectory, folderName);
                }
                soilFilePath = Path.Combine(soilFileDirectory, soilFileName);

                if (weatherFileDirectory.Trim() == "")
                {
                    string folderName;
                    folderName = @"Weather files\";
                    weatherFileDirectory = Path.Combine(workDirectory, folderName);
                }
                weatherFilePath = Path.Combine(weatherFileDirectory, weatherFileName);

                if (weatherStationFileDirectory.Trim() == "")
                {
                    string folderName;
                    folderName = @"Weather station files\";
                    weatherStationFileDirectory = Path.Combine(workDirectory, folderName);
                }
                weatherStationFilePath = Path.Combine(weatherStationFileDirectory, weatherStationFileName);

                runIDList.Add(runID);
                outputFileDirectoryList.Add(outputFileDirectory) ;
                outputFileNameList.Add(outputFileName);
                outputFilePathList.Add(outputFilePath);
                farmerFileDirectoryList.Add(farmerFileDirectory);
                farmerFileNameList.Add(farmerFileName);
                farmerFilePathList.Add(farmerFilePath);
                soilFileDirectoryList.Add(soilFileDirectory);
                soilFileNameList.Add(soilFileName);
                soilFilePathList.Add(soilFilePath);
                weatherStationIDList.Add(weatherStationID);
                weatherStationFileDirectoryList.Add(weatherStationFileDirectory);
                weatherStationFileNameList.Add(weatherStationFileName);
                weatherStationFilePathList.Add(weatherStationFilePath);
                weatherFileDirectoryList.Add(weatherFileDirectory);
                weatherFileNameList.Add(weatherFileName);
                weatherFilePathList.Add(weatherFilePath);
                line = sr.ReadLine();
            }

            runIDs = runIDList.ToArray();
            outputFileDirectories = outputFileDirectoryList.ToArray();
            outputFileNames = outputFileNameList.ToArray();
            outputFilePaths = outputFilePathList.ToArray();
            farmerFileDirectories = farmerFileDirectoryList.ToArray();
            farmerFileNames = farmerFileNameList.ToArray();
            farmerFilePaths = farmerFilePathList.ToArray();
            soilFileDirectories = soilFileDirectoryList.ToArray();
            soilFileNames = soilFileNameList.ToArray();
            soilFilePaths = soilFilePathList.ToArray();
            weatherStationIDs = weatherStationIDList.ToArray();
            weatherStationFileDirectories = weatherStationFileDirectoryList.ToArray();
            weatherStationFileNames = weatherStationFileNameList.ToArray();
            weatherStationFilePaths = weatherStationFilePathList.ToArray();
            weatherFileDirectories = weatherFileDirectoryList.ToArray();
            weatherFileNames = weatherFileNameList.ToArray();
            weatherFilePaths = weatherFilePathList.ToArray();
            return this;    
        }

        public string[] FarmerfileDirectories { get { return farmerFileDirectories; } set { farmerFileDirectories = value; } }
        public string[] FarmerFileNames { get { return farmerFileNames; } set { farmerFileNames = value; } }
        public string[] FarmerFilePaths { get { return farmerFilePaths; } set { farmerFilePaths = value; } }
        public int[] RunIDs { get { return runIDs; } set { runIDs = value; } }
        public string SimulationInputFileDirectory { get { return simulationInputFileDirectory; } set { simulationInputFileDirectory = value; } }
        public string SimulationInputFileName { get { return simulationInputFileName; } set { simulationInputFileName = value; } }
        public string SimulationInputFilePath { get { return simulationInputFilePath; } set { simulationInputFilePath = value; } }
        public string[] OutputFileDirectories { get { return outputFileDirectories; } set { outputFileDirectories = value; } }
        public string[] OutputFileNames { get { return outputFileNames; } set { outputFileNames = value; } }
        public string[] OutputFilePaths { get { return outputFilePaths; } set { outputFilePaths = value; } }
        public string[] SoilFileDirectories { get { return soilFileDirectories; } set { soilFileDirectories = value; } }
        public string[] SoilFileNames { get { return soilFileNames; } set { soilFileNames = value; } }
        public string[] SoilFilePaths { get { return soilFilePaths; } set { soilFilePaths = value; } }
        public string[] WeatherFileDirectories { get { return weatherFileDirectories; } set { weatherFileDirectories = value; } }
        public string[] WeatherFileNames { get { return weatherFileNames; } set { weatherFileNames = value; } }
        public string[] WeatherFilePaths { get { return weatherFilePaths; } set { weatherFilePaths = value; } }
        public string[] WeatherStationFileDirectories { get { return weatherStationFileDirectories; } set { weatherStationFileDirectories = value; } }
        public string[] WeatherstationFileNames { get { return weatherStationFileNames; } set { weatherStationFileNames = value; } }
        public string[] WeatherStationFilePaths { get { return weatherStationFilePaths; } set { weatherStationFilePaths = value; } }
        public int[] WeatherStationIDs { get { return weatherStationIDs; } set { weatherStationIDs = value; } }

    }
}
