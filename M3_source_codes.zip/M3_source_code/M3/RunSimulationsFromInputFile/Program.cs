﻿using System;
using System.Linq;
using ModelRunner_library;
using System.IO;
using System.Collections;

namespace RunSimulationsFromInputFile
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputFileDirectory;
            string inputFilePath;
            string inputFileName;
            SimulationInputFile simulationInputFile;

            inputFileDirectory = Directory.GetCurrentDirectory();
            inputFileName = "simulationInput.csv";
            inputFilePath = Path.Combine(inputFileDirectory,inputFileName);

            simulationInputFile = new SimulationInputFile();
            simulationInputFile.SimulationInputFilePath = inputFilePath;
            simulationInputFile = simulationInputFile.ReadSimulationInputFile();

            RunMultipleSimulations(simulationInputFile);
        }

        static void RunMultipleSimulations(SimulationInputFile simulationInputFile)
        {
            int[] runIDs;
            runIDs = simulationInputFile.RunIDs;

            for (int i = 0; i < runIDs.Length; i++)
            {
                StripIntercropModel model;
                model = new StripIntercropModel();

                model.FarmerFilePath = simulationInputFile.FarmerFilePaths[i];
                model.OutputFilePath = simulationInputFile.OutputFilePaths[i];
                model.SoilFilePath = simulationInputFile.SoilFilePaths[i];

                model.WeatherStationID = simulationInputFile.WeatherStationIDs[i];
                model.WeatherStationFilePath = simulationInputFile.WeatherStationFilePaths[i];
                model.WeatherFilePath = simulationInputFile.WeatherFilePaths[i];
                model.InitializeModelComponents();
                model.SimulateCropGrowth();
            }
        }

    }

}

